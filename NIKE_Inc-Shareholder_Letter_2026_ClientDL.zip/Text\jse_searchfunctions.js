// EZOnlineDocuments.com Search Functions

var include_num = 1;
var bold = 1;
//var cookies = document.cookie;
//var p = cookies.indexOf("d=");
var disallowedentry = '';
var userInput = '';
var saved_d = '';
var sorig = new Array();

var maxsearchresultdesk = 350; // The maximum number of characters in a search result sentence
var maxsearchresultmobile = 250;
var maxitemsperpage = 15; // The maximum number of results to show on a page
var pagestoshow = 5; //The max number of pages to enumerate
var startitem = 0;

startitem = getQueryVariable('s' + 'tartitem');
if (startitem == '') {
	startitem = 0;
}


/*
if (p != -1) {
	var st = p + 2;
	var en = cookies.indexOf(";", st);
	if (en == -1) {
		en = cookies.length;
	}
	var d = cookies.substring(st, en);
	d = unescape(d);
}

p = cookies.indexOf("disallowed=");
if (p != -1) {
	var st = p + 11;
	var en = cookies.indexOf(";", st);
	if (en == -1) {
		en = cookies.length;
	}
	disallowedentry = cookies.substring(st, en);
	//alert(disallowedentry);
}
*/
//alert('Decode:' + decodeURIComponent(getQueryVariable('d' + '1')));
d=null; //Initialize to null so it shows search form if no search
disallowedentry='';
if (getQueryVariable('d' + '1') != '') {
	d = unescape(getQueryVariable('d' + '1').replace(/\+/g, " "));
}
if (getQueryVariable('d' + '2') != '') {
	d = unescape(getQueryVariable('d' + '2').replace(/\+/g, " "));
}
if (getQueryVariable('d' + '0') != '') {
	d = unescape(getQueryVariable('d' + '0').replace(/\+/g, " "));
}
if (getQueryVariable('d' + 'X') != '') {
	d = unescape(getQueryVariable('d' + 'X').replace(/\+/g, " "));
}

var _ezSearchJobId = -1;
var _originalsearchterm = d;
var resultAssociatedJobId = new Array();
var resultJobResultsCount = new Array();
var resultMTBItems = new Array();
if (_ezSE01 == 1) { //If multidoc search is on 
	if (getQueryVariable('_ezSearchJobId') != '') {
	 _ezSearchJobId = unescape(getQueryVariable('_ezSearchJobId'));
	 //Set cookie to the Job oucjed
	 $.cookie('ezod_ezSearchJobId', _ezSearchJobId, { expires: 1 });
	} else {
		_ezSearchJobId = 0; //Default to all documents
		//Read from Cookie and change, if applicable
		if (typeof $.cookie('ezod_ezSearchJobId') === 'undefined'){
 			//no cookie - leave as default
		} else {
			_ezSearchJobId = $.cookie('ezod_ezSearchJobId');
		}
	}
	if (_ezSearchJobId != 0) { //Check to make sure we were passed a valid job id, if there is one
		if ($.inArray(parseInt(_ezSearchJobId),_ezSearchAvailableJobIds) == -1) {
			_ezSearchJobId = 0;
		}
	}
}


if (d!=null) {
	var od = d;
	var mmm = 0;
	//if (d.charAt(0) == '"' && d.charAt(d.length - 1) == '"') {
	//	mmm = 1;
	//}

	userInput = d;
	userInput = userInput.replace(/\\/g,"");
	userInput = userInput.replace(/\^/g,"");
	
	var NeedReplacingString = d;
	var ReplacingString = '';
	var charactertoadd2 = '';
  		for (var charindex2=0; charindex2 < NeedReplacingString.length; charindex2++) {
    			charactertoadd2 = NeedReplacingString.charAt(charindex2);
    			if (charactertoadd2 == "~") { charactertoadd2 = "";  }
    			if (charactertoadd2 == "\\") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\$") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\(") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\)") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\*") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\[") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\]") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\?") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\!") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\+") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\-") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\|") { charactertoadd2 = "\\" + charactertoadd2; }
    			//if (charactertoadd2 == '\"') { charactertoadd2 = "\\" + charactertoadd2; }
    			//if (charactertoadd2 == "\'") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\.") { charactertoadd2 = "\\" + charactertoadd2; }
    			if (charactertoadd2 == "\,") { charactertoadd2 = "\\" + charactertoadd2; }
    			//if (charactertoadd2 == "\,") { charactertoadd2 = ""; }
    			//if (charactertoadd2 == "\#") { charactertoadd2 = ""; }
    			//if (charactertoadd2 == "\&") { charactertoadd2 = ""; }
    			if (charactertoadd2 == "\^") { charactertoadd2 = "";  }
    			//alert(charactertoadd2);
			ReplacingString = ReplacingString + charactertoadd2;
		}	
		d = strrtrim(ReplacingString);
	

	// New 3/23/07 - have to replace foreign language characters 
	d = d.replace(/�/gi, "<IND~~TAG>szlig;");
	d = d.replace(/�/gi, "<IND~~TAG>Aacute;");
	d = d.replace(/�/gi, "<IND~~TAG>Atilde;");
	d = d.replace(/�/gi, "<IND~~TAG>Aring;");
	d = d.replace(/�/gi, "<IND~~TAG>Ccedil;");
	d = d.replace(/�/gi, "<IND~~TAG>Eacute;");
	d = d.replace(/�/gi, "<IND~~TAG>Euml;");
	d = d.replace(/�/gi, "<IND~~TAG>Iacute;");
	d = d.replace(/�/gi, "<IND~~TAG>Iuml;");
	d = d.replace(/�/gi, "<IND~~TAG>Ntilde;");
	d = d.replace(/�/gi, "<IND~~TAG>Oacute;");
	d = d.replace(/�/gi, "<IND~~TAG>Otilde;");
	d = d.replace(/�/gi, "<IND~~TAG>Ugrave;");
	d = d.replace(/�/gi, "<IND~~TAG>Yacute;");
	d = d.replace(/�/gi, "<IND~~TAG>aacute;");
	d = d.replace(/�/gi, "<IND~~TAG>atilde;");
	d = d.replace(/�/gi, "<IND~~TAG>aring;");
	d = d.replace(/�/gi, "<IND~~TAG>ccedil;");
	d = d.replace(/�/gi, "<IND~~TAG>eacute;");
	d = d.replace(/�/gi, "<IND~~TAG>euml;");
	d = d.replace(/�/gi, "<IND~~TAG>iacute;");
	d = d.replace(/�/gi, "<IND~~TAG>iuml;");
	d = d.replace(/�/gi, "<IND~~TAG>ntilde;");
	d = d.replace(/�/gi, "<IND~~TAG>oacute;");
	d = d.replace(/�/gi, "<IND~~TAG>otilde;");
	d = d.replace(/�/gi, "<IND~~TAG>ugrave;");
	d = d.replace(/�/gi, "<IND~~TAG>ucirc;");
	d = d.replace(/�/gi, "<IND~~TAG>yacute;");
	d = d.replace(/�/gi, "<IND~~TAG>yuml;");
	d = d.replace(/�/gi, "<IND~~TAG>reg;");
	d = d.replace(/�/gi, "<IND~~TAG>copy;");
	d = d.replace(/�/gi, "<IND~~TAG>Agrave;");
	d = d.replace(/�/gi, "<IND~~TAG>Acirc;");
	d = d.replace(/�/gi, "<IND~~TAG>Auml;");
	d = d.replace(/�/gi, "<IND~~TAG>AElig;");
	d = d.replace(/�/gi, "<IND~~TAG>Egrave;");
	d = d.replace(/�/gi, "<IND~~TAG>Ecirc;");
	d = d.replace(/�/gi, "<IND~~TAG>Igrave;");
	d = d.replace(/�/gi, "<IND~~TAG>Icirc;");
	d = d.replace(/�/gi, "<IND~~TAG>ETH;");
	d = d.replace(/�/gi, "<IND~~TAG>Ograve;");
	d = d.replace(/�/gi, "<IND~~TAG>Ocirc;");
	d = d.replace(/�/gi, "<IND~~TAG>Ouml;");
	d = d.replace(/�/gi, "<IND~~TAG>Oslash;");
	d = d.replace(/�/gi, "<IND~~TAG>Uacute;");
	d = d.replace(/�/gi, "<IND~~TAG>Uuml;");
	d = d.replace(/�/gi, "<IND~~TAG>THORN;");
	d = d.replace(/�/gi, "<IND~~TAG>agrave;");
	d = d.replace(/�/gi, "<IND~~TAG>acirc;");
	d = d.replace(/�/gi, "<IND~~TAG>auml;");
	d = d.replace(/�/gi, "<IND~~TAG>aelig;");
	d = d.replace(/�/gi, "<IND~~TAG>egrave;");
	d = d.replace(/�/gi, "<IND~~TAG>ecirc;");
	d = d.replace(/�/gi, "<IND~~TAG>igrave;");
	d = d.replace(/�/gi, "<IND~~TAG>icirc;");
	d = d.replace(/�/gi, "<IND~~TAG>eth;");
	d = d.replace(/�/gi, "<IND~~TAG>ograve;");
	d = d.replace(/�/gi, "<IND~~TAG>ocirc;");
	d = d.replace(/�/gi, "<IND~~TAG>ouml;");
	d = d.replace(/�/gi, "<IND~~TAG>oslash;");
	d = d.replace(/�/gi, "<IND~~TAG>uacute;");
	d = d.replace(/�/gi, "<IND~~TAG>uuml;");
	d = d.replace(/�/gi, "<IND~~TAG>thorn;");
	d = d.replace(/�/gi, "<IND~~TAG>euro;");
	d = d.replace(/�/gi, "<IND~~TAG>iexcl;");
	d = d.replace(/�/gi, "<IND~~TAG>laquo;");
	d = d.replace(/�/gi, "<IND~~TAG>raquo;");
	
	
	// New 5/26/05 - used saved_d in searching, make lower case, use regexp matching to ignore case
	saved_d = d;

	saved_d = saved_d.replace(/^\-|^\+/gi, "");
	saved_d = saved_d.replace(/#/gi, "<IND~~TAG>#35");
	saved_d = saved_d.replace(/&/gi, "&#38");
	saved_d = saved_d.replace(/'/gi, "&#39");
	//saved_d = saved_d.replace(/�/gi, "&#39");					
	//saved_d = saved_d.replace(/�/gi, "&#39");					
	//saved_d = saved_d.replace(/�/gi, "&#34");					
	//saved_d = saved_d.replace(/�/gi, "&#34");
	
	saved_d = saved_d.replace(/"/gi, "&#34");
	saved_d = saved_d.replace(/<IND~~TAG>/gi, "&");

	saved_d = saved_d.replace(/(\s+)/gi,' ');
	saved_d = saved_d.toLowerCase();
	
	
	var r = new Array();
	var totalresultcount = 0;


	if (mmm == 0) {
		var woin = new Array();
		// Remove spaces around numbers (since eliminated)
		//d = d.replace(/([\d])(\s+)([\d])/gi,'$1$3'); 
		//d = d.replace(/([\d])(\s+)([\d])/gi,'$1$3');
		//d = d.replace(/(\$)(\s+)([\d])/gi,'$1$3');					
		//d = d.replace(/(\$)(\s+)([\d])/gi,'$1$3');					
		var w = d.split(" ");
		for (var a = 0; a < w.length; a++) {
			woin[a] = 0;
			if (w[a].charAt(0) == '-') {
				woin[a] = 1;
			}
		}
		for (var a = 0; a < w.length; a++) {
			w[a] = w[a].replace(/^\-|^\+/gi, "");
			w[a] = w[a].replace(/�/gi, "-");
			w[a] = w[a].replace(/#/gi, "<IND~~TAG>#35");
			w[a] = w[a].replace(/&/gi, "&#38");
			w[a] = w[a].replace(/'/gi, "&#39");
			//w[a] = w[a].replace(/�/gi, "&#39");
			//w[a] = w[a].replace(/�/gi, "&#39");
			w[a] = w[a].replace(/"/gi, "&#34");
			//w[a] = w[a].replace(/�/gi, "&#34");
			//w[a] = w[a].replace(/�/gi, "&#34");
			w[a] = w[a].replace(/<IND~~TAG>/gi, "&");
			//w[a] = w[a].replace(/^/gi, "&#94");
			//alert(w[a]);
		}
		
		//New code to search the MTB if needed
		if (typeof mtbpages !== 'undefined' && mtbpages.length > 0) {
			//It has the MTB array
			var mtbrescount;
			mtbrescount = 0;
			for (var c = 0; c < mtbpages.length; c++) {

				tmpstr = mtbpages[c].substring(mtbpages[c].indexOf('^')+1);
				tmpstr = tmpstr.substring(tmpstr.indexOf('^')+1);
				tmpstr = tmpstr.toLowerCase();
				if (tmpstr.search(saved_d) >= 0) { //First check for the whole phrase
						resultMTBItems[mtbrescount] = mtbpages[c];
						mtbrescount++;
				} else { //Check each word
					pa = 0;
					nh = 0;
					for (var i = 0; i < woin.length; i++) {
						if (woin[i] == 0) {
							nh++;
							var pat = new RegExp(w[i], "i");
							var rn = tmpstr.search(pat);
							if (rn >= 0) {
								pa++;
							} else {
								pa = 0;
							}
						}
						if (woin[i] == 1) {
							var pat = new RegExp(w[i], "i");
							var rn = tmpstr.search(pat);
							if (rn >= 0) {
								pa = 0;
							}
						}
					}
					if (pa == nh) {
						resultMTBItems[mtbrescount] = mtbpages[c];
						mtbrescount++;
					}
				
				}

			}
			
			/*
			if (mtbrescount > 0 ) {
				//Has some mtb results
				alert('Has results');
			}
			*/
		
		}
		
		
		
		//New code to search a different set of arrays if necesary
		if (_ezSearchJobId == -1) { //Use Original Process
			a = 0;
			for (var c2 = 0; c2 < s.length; c2++) {
				// Remove spaces around numbers (since eliminated)
				s[c2] = s[c2].replace(/(\s+)/gi,' ');					
				s[c2] = s[c2].replace(/�/g,'-');					
				sorig[c2] = s[c2];
			}
			
			
			
			
			for (var c = 0; c < s.length; c++) {
				pa = 0;
				nh = 0;
				for (var i = 0; i < woin.length; i++) {
					if (woin[i] == 0) {
						nh++;
						var pat = new RegExp(w[i], "i");
						var rn = s[c].search(pat);
						if (rn >= 0) {
							pa++;
						} else {
							pa = 0;
						}
					}
					if (woin[i] == 1) {
						var pat = new RegExp(w[i], "i");
						var rn = s[c].search(pat);
						if (rn >= 0) {
							pa = 0;
						}
					}
				}
				if (pa == nh) {
					//r[a] = s[c];
					// Use tmpstr so searches for numbers do not include page numbers in the results
					tmpstr = sorig[c].substring(sorig[c].indexOf('^')+1);
					tmpstr = tmpstr.substring(tmpstr.indexOf('^')+1);
					tmpstr = tmpstr.toLowerCase();
					if (tmpstr.search(saved_d) >= 0) {
						r[a] = sorig[c];
						a++;
					}
				}
			}
		} else { //in multi document search
					a = 0;
					//Set the IDs of the jobs to search
					var searchthesejobids = new Array(); 
					var currentjobsearcharray = new Array(); 
					if (_ezSearchJobId == 0) {
						searchthesejobids = _ezSearchAvailableJobIds;
					} else {
						searchthesejobids[0] = _ezSearchJobId;
					}
			for (var curjobindex = 0; curjobindex < searchthesejobids.length; curjobindex++) {
				curjobid = searchthesejobids[curjobindex];
				currentjobsearcharray = _ezAllDocSearch[curjobid];
				resultJobResultsCount[curjobid] = 0;
				
				for (var c2 = 0; c2 < currentjobsearcharray.length; c2++) {
					// Remove spaces around numbers (since eliminated)
					currentjobsearcharray[c2] = currentjobsearcharray[c2].replace(/(\s+)/gi,' ');					
					currentjobsearcharray[c2] = currentjobsearcharray[c2].replace(/�/g,'-');					
					sorig[c2] = currentjobsearcharray[c2];
				}
				for (var c = 0; c < currentjobsearcharray.length; c++) {
					pa = 0;
					nh = 0;
					for (var i = 0; i < woin.length; i++) {
						if (woin[i] == 0) {
							nh++;
							var pat = new RegExp(w[i], "i");
							var rn = currentjobsearcharray[c].search(pat);
							if (rn >= 0) {
								pa++;
							} else {
								pa = 0;
							}
						}
						if (woin[i] == 1) {
							var pat = new RegExp(w[i], "i");
							var rn = currentjobsearcharray[c].search(pat);
							if (rn >= 0) {
								pa = 0;
							}
						}
					}
					if (pa == nh) {
						//r[a] = currentjobsearcharray[c];
						// Use tmpstr so searches for numbers do not include page numbers in the results
						tmpstr = sorig[c].substring(sorig[c].indexOf('^')+1);
						tmpstr = tmpstr.substring(tmpstr.indexOf('^')+1);
						tmpstr = tmpstr.toLowerCase();
						if (tmpstr.search(saved_d) >= 0) {
							r[a] = sorig[c];
							resultAssociatedJobId[a] = curjobid;
							a++;
							resultJobResultsCount[curjobid]++;
						}
					}
				}
			}
			
		}
		totalresultcount = a;
		if (mtbrescount > 0 ) {
			totalresultcount++; //Add one for the MTB result
		}
	}
}


function return_query() {
	if (od!=null)
		document.getElementById('d1').value = od.replace(/\\/g,"");
}

function num_jse() {
	document.write(totalresultcount);
}

function htmlEncode(value){
  //create a in-memory div, set it's inner text(which jQuery automatically encodes)
  //then grab the encoded contents back out.  The div never exists on the page.
  return $('<div/>').text(value).html();
}


function out_jse() {
	if (totalresultcount == 0) {
		document.write('<table wdith="100%"><tr><td valign="top"><br /><h2>' + _ez30[30] + '</h2><br />');
		document.write('<span class="eznsearchtxt1">' + _ez30[12] + ' "<font class="search-searchterm"><b>' + htmlEncode(userInput) + '</b></font>". ' + _ez30[13]) + '</span>';
		showsearchform();
		document.write('</td></tr></table><br /><br />');
		return;
	}
	

	var imagepath = "../Thumbs/%d";
	bgtoggle = 0;
	
	startitem = parseInt(startitem);
	enditem = startitem + maxitemsperpage;

	//Some cleanup if there are MTB results = mtb is the first result
	if (mtbrescount > 0) {	
		if (startitem == 0) {
			//On the first page, reduce end item by 1
			enditem--;
		} else {
			//On all other pages, reduce start item and end item by one to account for the shift
			startitem--;
			enditem--;
		}
		
	}
	
	if (r.length < enditem) {
		enditem = r.length;
	}


	var currentshowingjobid = 0;
	var currentjobresultnum = 0;
	var currentlyvisibledocumentname = '';

	//New first output the MTB result item
	if (mtbrescount > 0 && startitem == 0) { //On page 1 and we have mtb results
		bgtoggle = 1; //Start the regular results on the right color
		//First write out the thumbnail portion
		document.writeln('<table width="100%" class="search-resultsrow search-resultsrowodd" border="0" cellpadding="0" cellspacing="0" style="">');
		document.writeln('<tr>');
		document.writeln('<td><div class="container" style="padding-top:2px; padding-bottom:2px;"><div class="three columns" style="text-align:center;">');
		searchresulturl = 'meettheboard.htm';
		var mtbthumb = 'thumb_meettheboard.gif';
		
		
		document.writeln('<a href="' + searchresulturl +  '" class="box"><img src="', imagepath.replace("%d", mtbthumb), '" border=0 alt="' + _ez30[5] + ' ' + _ez30[14] + '" title="' + _ez30[5] + ' ' + _ez30[14] + '"></a>');
		document.writeln('<div class="display768orlarger ezsearchtextbigclickhere" style="text-align:center;"><div class="nav-NextSmall"></div><a href="' + searchresulturl + '">' + _ez30[277] + '</a></div>');
		
		document.writeln('</div>');
		document.writeln('<div class="thirteen columns"><div style="padding-left: 5px; padding-right: 5px; padding-top:10px; padding-bottom:10px;">');
	
		document.write('<span class="ezsearchtxt4">');
		
		document.write('<div class="ezmtbsearchheading">' + _ez30[282] + '</div><ul class="ezmtbsearchresul">');
					
		var committeecount = 0
		var biocount = 0
		var skillcount = 0;
		var mtbcuritemtext = '';
		
		var runningcommitteecount = 0;
		var runningbiocount = 0;
		var runningskillcount = 0;
		
		for (var mtbresloopcnt = 0; mtbresloopcnt < mtbrescount; mtbresloopcnt++) {
			var splitresultitem = resultMTBItems[mtbresloopcnt].split("^");
			mtbcuritemtext = splitresultitem[0]
			if (mtbcuritemtext.indexOf('Committee:') !== -1) {
				committeecount += 1;
			}
			
			if (mtbcuritemtext.indexOf('Biography:') !== -1) {
				biocount += 1;
			}
			
			if (mtbcuritemtext.indexOf('Skill:') !== -1) {
				skillcount += 1;
			}
				
			
		}
					
		for (var mtbresloopcnt = 0; mtbresloopcnt < mtbrescount; mtbresloopcnt++) {
			var splitresultitem = resultMTBItems[mtbresloopcnt].split("^");
			searchresulturl = splitresultitem[5].replace(/~/gi, "");
			mtbcuritemtext = splitresultitem[0];
			
			if (mtbcuritemtext.indexOf('Committee:') !== -1 && committeecount > 1 ) {
				runningcommitteecount = runningcommitteecount + 1;
				if (runningcommitteecount == 1) {
					document.writeln('<li class="ezmtbsearchresli">Committees:');
				}
				mtbcuritemtext = mtbcuritemtext.replace('Committee:','');
				document.write('<a href="' + searchresulturl + '" class="ezmtbsearchresa">' + mtbcuritemtext + '</a>');
				
				if (runningcommitteecount == committeecount) {
					document.writeln('</li>');
				} else {
					document.writeln(',');
				}
			} else if (mtbcuritemtext.indexOf('Biography:') !== -1 && biocount > 1 ) { 
				runningbiocount = runningbiocount + 1;
				if (runningbiocount == 1) {
					document.writeln('<li class="ezmtbsearchresli">Biographies:');
				}
				mtbcuritemtext = mtbcuritemtext.replace('Biography:','');
				document.write('<a href="' + searchresulturl + '" class="ezmtbsearchresa">' + mtbcuritemtext + '</a>');
				
				if (runningbiocount == biocount) {
					document.writeln('</li>');
				} else {
					document.writeln(',');
				}
			} else if (mtbcuritemtext.indexOf('Skill:') !== -1 && skillcount > 1 ) { 
				runningskillcount = runningskillcount + 1;
				if (runningskillcount == 1) {
					document.writeln('<li class="ezmtbsearchresli">Skills:');
				}
				mtbcuritemtext = mtbcuritemtext.replace('Skill:','');
				document.write('<a href="' + searchresulturl + '" class="ezmtbsearchresa">' + mtbcuritemtext + '</a>');
				
				if (runningskillcount == skillcount) {
					document.writeln('</li>');
				} else {
					document.writeln(',');
				}
			} else {
				document.writeln('<li class="ezmtbsearchresli"><a href="' + searchresulturl + '" class="ezmtbsearchresa">' + mtbcuritemtext + '</a></li>');
			}
			
		}
		
		document.write('</ul></span>');
		
		searchresulturl = 'meettheboard.htm';
		document.writeln('<div class="display420orsmaller"><br /><div class="nav-NextSmall"></div> <a href="' + searchresulturl + '">' + _ez30[5] + ' ' + _ez30[14] + '</a></div>');
		document.writeln("</td>");
		document.writeln("</tr>");
		document.writeln("</table><hr size=1 class='search-hr' />");
		
	}
	
	for (var a = startitem; a < enditem; a++) {
		var os = r[a].split("^");
		var br;
		var resultjobid = 0;
		var resultadditionurldirectory = '';
		var resultadditionthumbdirectory = '';
		if (resultAssociatedJobId.length > 0) {
				resultjobid = resultAssociatedJobId[a];
				resultadditionurldirectory = _ezpathtojobid[resultjobid];
				if (resultadditionurldirectory != '') {
					resultadditionurldirectory += _ezSearchCurrentHTMLDir + '/';
				}
				resultadditionthumbdirectory = _ezpathtojobid[resultjobid];
				if (resultadditionthumbdirectory != '') {
					imagepath = resultadditionthumbdirectory + '/Thumbs/%d';
				}
				
				if (currentshowingjobid != resultjobid) {
					currentjobresultnum = 1;
					if (startitem > 0) { //If we are on page 2, etc - we have to figure out the current job result number
						var pagecounter = 0;
						for (var checkpage = startitem - 1; checkpage >= 0; checkpage--) {
							if ( resultAssociatedJobId[checkpage] == resultjobid ) { //If the previous screen had some from this job
								pagecounter++;
							} else { //Once we hit another job, we are done
								break;
							}
						}
						currentjobresultnum += pagecounter;
					}
					currentshowingjobid = resultjobid;
					
					currentlyvisibledocumentname = _ezKitDescriptions[currentshowingjobid];
					var numberofresultsforthisjob = 0;
					numberofresultsforthisjob = resultJobResultsCount[currentshowingjobid];
					_ezWriteMultiDocResultsHeader(currentlyvisibledocumentname, numberofresultsforthisjob);
				} else {
					currentjobresultnum += 1;
				}
		}

		//for (var i = 0; i < w.length; i++) {
		//		br = "<u>" + d + "</u>";
		//		var KeyWord = new RegExp("(" + w[i] + ")","ig");
		//		os[2] = os[2].replace(KeyWord,String.fromCharCode(2) + "$1" + String.fromCharCode(3));
		//}
		//var KeyWord = new RegExp("(" + saved_d + ")","i");
		var KeyWord = new RegExp("(" + saved_d + ")","gi");
		var StartIndicator = String.fromCharCode(2);
		var EndIndicator = String.fromCharCode(3);
		var StartExpression = new RegExp("(" + StartIndicator + ")","gi");
		var EndExpression = new RegExp("(" + EndIndicator + ")","gi");
		
		os[2] = os[2].replace(KeyWord,StartIndicator + "$1" + EndIndicator); // Added 5/26/05 to only search for whole words in search criteria
		
		var searchstr = '';
		var numfound;
		var tmpstr;
		var firstmatch;
		var Sentences = os[2].split(". ");
	
		//alert(r[a]);
		for (var moblook=0; moblook <= 1; moblook++) {
			numfound = 0;
			firstmatch = 0;
			tmpstr = '';
			if (moblook == 0) { //desktop version
				searchstr = searchstr + '<div class="display768orlarger ezsearchtextdesk1">';
				maxsearchresult = maxsearchresultdesk;
			} else {
				searchstr = searchstr + '<div class="display420orsmaller ezsearchtextmobile1">';
				maxsearchresult = maxsearchresultmobile;
			}
			
			for (var i=0; (i < Sentences.length) && (numfound < 3); i++) {
				var pat = new RegExp(EndIndicator);

				var rn = Sentences[i].search(pat);
				if (rn>0) {
					tmpstr = Sentences[i];
					while ((tmpstr.length < maxsearchresult) && (i < (Sentences.length-1))) {
						i++;
						tmpstr = tmpstr + '. ' + Sentences[i];
					}
					firstmatch = tmpstr.indexOf(StartIndicator);
					if (firstmatch > (maxsearchresult - 40)) {
						tmpstr = '...' + tmpstr.substring(firstmatch - 40,firstmatch - 40 + maxsearchresult);
					}
					if (tmpstr.length > maxsearchresult) {
						tmpstr = tmpstr.substring(0,maxsearchresult) + '...';
					}
					
					// Added in unusual case of start being removed
					if ((tmpstr.indexOf(StartIndicator) < 0) && (tmpstr.indexOf(EndIndicator) < 0)) {
						// skip
					} else {
						if (tmpstr.indexOf(StartIndicator) < 0) {
							tmpstr = StartIndicator + tmpstr;
						}
						if ( tmpstr.indexOf(EndIndicator) < 0) {
							tmpstr = tmpstr + EndIndicator;
						}
							
						while (tmpstr.match(StartExpression).length > tmpstr.match(EndExpression).length) {
							tmpstr = tmpstr + EndIndicator;
						}
						
						while (tmpstr.match(StartExpression).length < tmpstr.match(EndExpression).length) {
							tmpstr = StartIndicator + tmpstr;
						}
						
						searchstr = searchstr + tmpstr;
						numfound++;
					}
					if (numfound < 3) { searchstr = searchstr + "<br /><br />"; }
				}
			}
			searchstr = searchstr + '</div>';
		}

		
		searchstr = searchstr.replace(StartExpression,'<span class="searchfounditem">');
		searchstr = searchstr.replace(EndExpression,'</span>');
		//if (numfound > 0) {
			// Found matches in sentence array 
			bgtoggle++;
			if (bgtoggle > 1) bgtoggle = 0;
			if (bgtoggle > 0)
				document.writeln('<table width="100%" class="search-resultsrow search-resultsrowodd" border="0" cellpadding="0" cellspacing="0" style="">');
			else
				document.writeln('<table width="100%" class="search-resultsrow search-resultsroweven" border="0" cellpadding="0" cellspacing="0" style="">');

			document.writeln('<tr>');
			document.writeln('<td><div class="container" style="padding-top:2px; padding-bottom:2px;"><div class="three columns" style="text-align:center;">');
			searchresulturl = os[5].replace(/~/gi, "");
			// Adjust link if in a zoom or 2 page view
			if (_ez01.indexOf('_z1') != -1) {
				searchresulturl = _EZF23(searchresulturl,'_z1');
			} 
			if (_ez01.indexOf('_z2') != -1) {
				searchresulturl = _EZF23(searchresulturl,'_z2');
			}
			if (_ez01.indexOf('-twopage_large') != -1) {
				searchresulturl = _EZF23(searchresulturl,'_large');  // Result has -twopage, just needs _large
			} else {
				if (_ez01.indexOf('-twopage') != -1) {
					searchresulturl = _EZF23(searchresulturl,'-twopage');
				}
			}
			searchresulturl = resultadditionurldirectory + searchresulturl;

			if (os[4].length < 3) {
				document.writeln('<br /><br /><i>' + _ez30[62] + '</i><br /><br />');
			} else {
				if (_ezSE01 == 1) { //If in multi-doc
					document.writeln('<div class="display420orsmaller ezkitsearchmobiledocnametext">');
					document.writeln(currentjobresultnum + '. ');
					document.writeln(currentlyvisibledocumentname + ', ' + _ez30[38] + ' ' + os[0]);
					document.writeln('</div>');
				} 
				document.writeln('<a href="' + searchresulturl +  '" class="box"><img src="', imagepath.replace("%d", os[4].replace(/~/gi, "")), '" border=0 alt="' + _ez30[5] + ' ' + _ez30[14] + '" title="' + _ez30[5] + ' ' + _ez30[14] + '"></a>');
				document.writeln('<div class="display768orlarger ezsearchtextbigclickhere" style="text-align:center;"><div class="nav-NextSmall"></div><a href="' + searchresulturl + '">' + _ez30[277] + '</a></div>');
			}
			document.writeln('</div>');
			document.writeln('<div class="thirteen columns"><div style="padding-left: 5px; padding-right: 5px; padding-top:10px; padding-bottom:10px;">');

			//If on a Kit, write the document name and result number
			if (_ezSE01 == 1) {
				document.writeln('<table><tr class="display768orlarger ezkitsearchdeskdocnametext" style="display: table-row;"><td>');
				document.writeln('<span class="ezsearchtxt2">');
				document.writeln(currentjobresultnum + '.');
				document.writeln('</span>');
				document.writeln('</td><td>');
				document.writeln('<span class="ezsearchtxt3">');
				document.writeln(currentlyvisibledocumentname + ', ' + _ez30[38] + ' ' + os[0]);
				document.writeln('</span>');
				document.writeln('</td></tr><tr><td></td><td>');
			} else {
				document.write('');
			}
			document.write('<span class="ezsearchtxt4">');
					
			searchstr = searchstr.replace(/&#35/gi, "#");
			searchstr = searchstr.replace(/&#39/gi, "'");
			searchstr = searchstr.replace(/&#34/gi, '"');
			searchstr = searchstr.replace(/&#38/gi, "&");
	
			document.writeln(searchstr);
		
			document.writeln('<div class="display420orsmaller"><br /><div class="nav-NextSmall"></div> <a href="' + searchresulturl + '">' + _ez30[5] + ' ' + _ez30[14] + '</a></div>');
			if (_ezSE01 == 1) {
				document.writeln('</div></div></div></td></tr></table>');
			} else {
				document.writeln('');
			}
			//document.writeln('<span class="ezsearchtxt5">' + _ez03 + '</span>');
		
			document.writeln("</td>");
			document.writeln("</tr>");
			document.writeln("</table><hr size=1 class='search-hr' />");
			
		//}
	}
}

// _EZF50 = showsearchresults
function _EZF50() {
	if (_ez18 < 5) {
		document.write('		<td width="1%">&nbsp;</td>		<td valign="top">');  // New left border is needed before content
		document.write('<blockquote>' + _ez30[15] + ' ' + _ez30[124] +  '</blockquote>');
	} else {
		return_query();

		if ((d!=null) && (userInput != '')) {
			totalpages1 = 0;
			curpage1 = 0;
			totalpages1 = Math.ceil(totalresultcount/maxitemsperpage);
			startitem = parseInt(startitem);
			curpage1 = Math.ceil(startitem/maxitemsperpage) + 1;
			
			var curdocumentname = '';
			if (_ezSE01 == 1) { //If in a kit mult doc search
				curdocumentname = _ez30[193];
				if (_ezSearchJobId > 0) {
					curdocumentname = _ezKitDescriptions[_ezSearchJobId];
				}
			} 
			
			document.write('<td colspan="3">');
			if (_ezSE01 == 1) { //If a multi doc search
				showjobsearchselector(_ezSearchJobId,_originalsearchterm);
			}
			

			
			if (totalresultcount > 0) { 
				if (_ezSE01 != 1) {
					_ezWriteSingleDocResultsHeader(curdocumentname);
				}
			} else {
				_ezWriteNoResultsHeader(curdocumentname);
			}
			
			document.write('</td></tr><tr>');
			document.write('<td width="100%" valign="top">');  // New left border is needed before content
			if (curpage1 > 1) {
				showpagenumbering(curpage1, totalpages1);
			}
			showdisallowed(disallowedentry);
			out_jse();
			if (totalresultcount > 0) {
				showpagenumbering(curpage1, totalpages1);
			}
		} else {
			document.write('<td colspan="3"><div class="display960orlarger"><table width="100%" cellpadding="0" cellspacing="0" class="search-headerrow"><tr><td valign="bottom"><h2>&nbsp;' + _ez30[25]  + '</h2></td>');
			document.write('<td  class="display960orlarger"><i><span class="ezsearchtxt7">');
			document.write(_ez30[23]);
			document.write('</span></i></td></tr></table></div></td></tr>   <tr>');
			document.write('		<td width="1%">&nbsp;</td>		<td valign="top">');  // New left border is needed before content			
			showdisallowed(disallowedentry);
			document.write('<table width="100%"><tr><td valign="top"><h2>' + _ez30[24] + '</h2><span class="ezsearchtxt8">' + _ez30[26]);
			showsearchform();
			document.write('</span></td></tr></table>');
		}
	}
}

function _ezWriteNoResultsHeader(curdocumentname) {
	document.write('<div class="container display960orlarger search-headerrow"><div class="four columns"><h2>&nbsp;' + _ez30[25]  + '</h2></div>');
	document.write('<div class="ten columns"><div style="padding-left:5px; padding-top:5px; padding-bottom:5px;"><i><span class="ezsearchtxt9">');
	document.write(_ez30[20] + ' "<font class="search-searchterm"><b>' + htmlEncode(userInput) + '</b></font>" ' + _ez30[21] + '<br />  ');
	document.write(_ez30[22]);
	if (_ezSE01 == 1) { //If in a kit mult doc search
		document.write('<br/>' + _ez30[196] + ' ' + curdocumentname); //Showing results for
	}
	document.write('</span></i></div></div>');
}

function _ezWriteSingleDocResultsHeader(curdocumentname) {
	document.write('<div class="container search-headerrow"><div class="four columns"><h2>&nbsp;' + _ez30[25]  + '</h2></div>');
	document.write('<div class="ten columns"><div style="padding-left:5px; padding-top:5px; padding-bottom:5px;"><i><span class="ezsearchtxt10">');
	document.write(_ez30[16] + ' "<font class="search-searchterm"><b>' + htmlEncode(userInput) + '</b></font>" ' + _ez30[17] + ' ' + totalresultcount + ' ' + _ez30[18] + '<br />  ');
	//document.write(_ez30[40] + ' ' + curpage1 + ' ' + _ez30[41] + ' ' + totalpages1 + ' ' + _ez30[42] + '.<br />  ');			
	document.write(_ez30[19]);
	if (_ezSE01 == 1) { //If in a kit mult doc search
		document.write('<br/>' + _ez30[196] + ' ' + curdocumentname); //Showing results for
	}
	document.write('</span></i></div></div></div>');
}

function _ezWriteMultiDocResultsHeader(curdocumentname, resultscountnum) {
	document.write('<table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:6px;" class="search-headerrow">');
	document.write('<tr><td valign="bottom" style="padding-top:8px; padding-left:10px;"><h2 style="font-weight:bold;">' + _ez30[25]  + ' - ' + curdocumentname + '</h2></td></tr>');
	document.write('<tr><td style="padding-top:2px; padding-left:10px; padding-bottom:8px;"><i><span class="ezsearchtxt11">');
	document.write(_ez30[199] + ' "<font class="search-searchterm"><b>' + htmlEncode(userInput) + '</b></font>" ' + _ez30[17] + ' ' + resultscountnum + ' ' + _ez30[18] + '');
	document.write('</span></i></td></tr></table>');
}

function showpagenumbering(curpage1, totalpages1) {
if (totalpages1 > 1) {
	document.write('<table width="100%" border="0"><tr><td align="center" valign="middle"><br />');
	if (curpage1 > 1) { //Previous Page Show
		newstartitem = (curpage1 - 2) * maxitemsperpage;
		document.writeln('<a href="' + _ez01 + '?s' + 'tartitem=' + newstartitem + '&_ezSearchJobId=' + _ezSearchJobId + '&d1=' + escape(userInput) + '" class="searchnav">' + _ez30[44] + '</a>');
	}
	
	startdisplaypage = 1;
	enddisplaypage = totalpages1;
	
	if (pagestoshow < totalpages1) {
		startdisplaypage = curpage1 - Math.ceil(pagestoshow/2);
		if (startdisplaypage < 1) {
			startdisplaypage = 1;
		}
		
		enddisplaypage = startdisplaypage + pagestoshow - 1;
		if (enddisplaypage > totalpages1) {
			enddisplaypage = totalpages1;
			startdisplaypage = enddisplaypage -pagestoshow + 1;
		}
	}
	
	for (var a = startdisplaypage; a <= enddisplaypage; a++) {
		newstartitem = (a - 1) * maxitemsperpage;
		if (a == curpage1) {
			document.writeln('<span class="searchnavcurrent">' + a + '</span>');
		}
		else {
			document.writeln('<a href="' + _ez01 + '?s' + 'tartitem=' + newstartitem + '&_ezSearchJobId=' + _ezSearchJobId + '&d1=' + escape(userInput) + '" class="searchnav">' + a + '</a>');	
		}
	}
	
	if (curpage1 < totalpages1) {
		newstartitem = curpage1 * maxitemsperpage;
		document.writeln('<a href="' + _ez01 + '?s' + 'tartitem=' + newstartitem + '&_ezSearchJobId=' + _ezSearchJobId + '&d1=' + escape(userInput) + '" class="searchnav">' + _ez30[43] + '</a>');
	}
	
	document.write('<br /><br /></td></tr></table>');	
}
}



function showdisallowed(disallowedentry) {
	if (disallowedentry != '') {
		document.write('<blockquote><font class="search-searchterm"><b>' + _ez30[27] + ' ' + disallowedentry + ' ' + _ez30[28] + '</font></blockquote>'); 
	}
}

function showsearchform() {
	_EZF01();
	document.write('<div id="noresultssearchdiv" style="margin-top:10px;"><form name="jse_FormX" method="get" action="' + _ez01 + '"  onsubmit="return _EZF02(\'dX\');"><ul>');
	searchbuttonclass = 'nav_EZSearchButton';
	document.write('<li><input type="text" size="' + _ez61 + '" name="dX" class="textinput ezSearchTextInput" id="dX"  /></li>');
	document.write('<li><input type="submit" onclick="return _EZF02(\'dX\');" name="searchButton" value="        " style="font-size:30px;" class="' + searchbuttonclass + '" id="ButtonX" /></li>');
	if (_ezSE01 == 1) { //If in a kit mult doc search
		document.write('<li><select name="_ezSearchJobId" id="_ezSearchJobIdX">');
		document.write('<option value="0"');
		if (_ezSearchJobId == 0) {
			document.write(' selected ');
		}
		document.write('>' + _ez30[193] + '</option>'); //all Documents
		
		for (var curjobindex = 0; curjobindex < _ezSearchAvailableJobIds.length; curjobindex++) {
				var curjobid = _ezSearchAvailableJobIds[curjobindex];
				document.write('<option value="' + curjobid + '"');
				if (_ezSearchJobId == curjobid) {
				document.write(' selected ');
			}
				document.write('>' + _ezKitDescriptions[curjobid] + '</option>');
				
		}
		document.write('</select></li>');
	}
	document.write('</ul></form></div>' + _ez03);
}

//193	All Documents
//194	Show results for:
//195	Change Document


function showjobsearchselector(_selectedJobId, _originalsearchstring) {
	
	_originalsearchstring = _originalsearchstring.replace(/"/gi, "&#34");
	document.write("<div id='divjobsearchselector' style='margin-left: 10px; margin-top:4px; margin-bottom:-9px;'>");
	document.write('<form name="jse_FormX" method="get" action="' + _ez01 + '"  onsubmit="return _EZF02(\'dX\');">');
	document.write(_ez30[194] + ' ');
	document.write('<input type="hidden" name="dX" class="textinput" ID="dX" value="' + _originalsearchstring + '" />');

	document.write('<select name="_ezSearchJobId" id="_ezSearchJobId1" onchange="this.form.submit();">');
	document.write('<option value="0"');
	if (_selectedJobId == 0) {
		document.write(' selected ');
	}
	document.write('>' + _ez30[193] + '</option>'); //all Documents
	
	for (var curjobindex = 0; curjobindex < _ezSearchAvailableJobIds.length; curjobindex++) {
			var curjobid = _ezSearchAvailableJobIds[curjobindex];
			document.write('<option value="' + curjobid + '"');
			if (_selectedJobId == curjobid) {
				document.write(' selected ');
			}
			document.write('>' + _ezKitDescriptions[curjobid] + '</option>');
				
	}
	
	document.write('</select>');

	//document.write('&nbsp; &nbsp; <input type="submit" onclick="return _EZF02(\'dX\');" name="searchButton" value="' + _ez30[195] + '" class="textbutton" ID="ButtonX" />');

	document.write('</form>' + _ez03);
	document.write('</div>');
	
}
