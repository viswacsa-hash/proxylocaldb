<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<!-- EZOnlineDocuments.com: EnhancedResponsive Ver.Jan2017 --> 

<title>NIKE, Inc. 2026 Annual Report</title>
<meta http-equiv="X-UA-Compatible" content="IE=EDGE" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, shrink-to-fit=no, viewport-fit=contain" />

<link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>

<style>
@font-face {
    font-family: 'Helvetica Neue';
    src: url('images/helveticaneue.eot');
    src: url('images/helveticaneue.eot?#iefix') format('embedded-opentype'),
         url('images/helveticaneue.woff') format('woff'),
         url('images/helveticaneue.ttf') format('truetype'),
         url('images/helveticaneue.svg#helveticaneue') format('svg');
    font-weight: normal;
    font-style: normal;

}
</style>
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">

<link rel="stylesheet" href="Text/font-awesome.min.css" type="text/css" />
<link rel="stylesheet" href="Text/styles.css" type="text/css" />
<link rel="stylesheet" href="Text/skeleton1440.css" type="text/css" />
<link rel="stylesheet" href="Text/mc_styles_switcher.css" type="text/css" />


<style type="text/css">
/* #ez_contentbox {	background: url(images/body-bg777.jpg) top center no-repeat; } */
#ez_logobox {	height: 110px; }
</style>


<!--[if lt IE 9]>
<link rel="stylesheet" href="Text/mc_styles_960.css" type="text/css" />
<link rel="stylesheet" href="Text/ie8_specific_styles.css" type="text/css" />
<![endif]-->

<!--[START-LJ]-->
<script type='text/javascript' src='Text/quickmenu.js'></script>
<!--[END-LJ]-->

<script type="text/javascript" src='Text/css_browser_selector.js'></script>
<script type="text/javascript" src="Text/browser-detection.js"></script>

<!--[if lt IE 7]>
<style type="text/css">	
	A.box   { border : thin solid #f47920;}
	A.box:visited { border : thin solid  #f47920;}
	A.box:hover{border : thin solid  #d86100;}
</style>
<![endif]-->

<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />


<script type="text/javascript">
//<![CDATA[
var _ez16 = 2; 
var _ez09 = 0;
var _ez20 = 'HTML1/financials.htm';
var _ez21 = '{nexturl}';
var _ez22 = 'HTML1/default.htm';
var _ez23 = 'HTML1/financials.htm';
var _ezIsTilesPage = '{hasTilesURL}';
var _ez24 = 777;
var _ezB04 = 776 + 1;
var _ezB05 = 1000 + 1;
var _ezB06 = 777;
var _ez72 = 'Not In Navigation';
var _ez47 = '{prevnormalurl}';
var _ezB03 = '';
var _ezB38 = 2;
var isSinglePage = '{has2PageURL}';
var isPaired = 'false';
var _ez73 = 'contents.htm';
var _ez80 = 'print.htm';
var _ez01 = 'results.htm';
var _ez81 = 'thumbnails.htm';
var _ez82 = 'help.htm';
var _ezB01 = '';
var _ezB02 = '';

//]]>
</script>
<script type="text/javascript" src="Text/localization-english.js"></script>
<script type='text/javascript' src='Text/jquery-3.5.1.min.js'></script>
<script type='text/javascript' src='Text/jquery-migrate-1.4.1.min.js'></script>
<script type='text/javascript' src='Text/jquery.cookie.js'></script>
<script type="text/javascript" src="Text/jse_form.js"></script>
<script type="text/javascript" src="Text/jse_fixedheader.js"></script>
<script type="text/javascript" src="Text/settings.js"></script>
<script type="text/javascript" src="Text/openurl.js"></script>

<script type="text/javascript" src="Text/ddsmoothmenu.js"></script>
<script type="text/javascript" src="Text/combinedjs1.js"></script>


<!--[if gt IE 8]><!-->
<script type="text/javascript" src="Text/combinedjs_noie8_2.js"></script>
<!--<![endif]-->
<script type="text/javascript">
//<![CDATA[
_EZF04('financials-thumbview.htm','');
//]]>
</script>
<script type='text/javascript' src='Text/responsivefunctions.js'></script>

<link rel="stylesheet" href="../responsive/responsive.css" type="text/css" />
</head>



<body>
<!--[if lt IE 9]> 
<style>
.ez_oldbrowserwarningcss { display: block !important; padding: 150px 150px 150px 150px; background-color: #333333; color: white; font-size:20px;  }
</style>
<![endif]-->

<div class="ez_oldbrowserwarningcss" style="display:none;">
<b>Warning</b>: your browser is no longer supported.<br/><ul><li><a href="http://www.ezonlinedocuments.com/browsers" target="_blank">CLICK HERE</a> to review the supported browser list.</li><li><a href="images/NIKE-Shareholder_Letter_2026.pdf" target="_blank">CLICK HERE</a> to download a PDF version of this report to read and/or print.</li></ul>
</div>






<div class="ezwrapper"><div class="ez_bigbgdiv ez_bigbgoverride_{currenturl}">
<div class="display768orsmaller" id="ezmobilenavbox-outer">
<div id="ezmobilenavbox-inner"><!-- MOBILE DOC SWITCHER -->
 <div id="mobile-docswitchtabs">&nbsp;&nbsp;<font color="F47920"><b>CEO Letter to Shareholders</b></font>&nbsp;|&nbsp;&nbsp;<a href="https://materials.proxyvote.com/NIKE/NPS26" class="ez_navbartop">Proxy Statement</a>&nbsp;|&nbsp;&nbsp;<a href="https://materials.proxyvote.com/NIKE/FORM10K26" class="ez_navbartop">10-K</a></div>
<div class="container clearfix">
<div id="ezmobilelogoouterdiv">
<div id="ezmobilelogoinnerdiv">
	<a href="default.htm" id="mobilelogolink"><img src="images/logo-mobile.png" /></a>
</div>
</div>
<div style="" id="ezmobilebuttonandmenudiv">
          <nav id="menu" class="navigation" role="navigation">
		  <a href="#" class="tplnavsmallbutton" id="btnMobileMenuOnResponsive">
		  <div id="mobilemenuclosed">
		  <div class="nav-MenuMobile"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Menu" title="Menu" /></div><div class="navMobileText">Menu</div>
		  </div>
		  <div id="mobilemenuopen">
		  <div class="nav-MenuCloseMobile"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Close" title="Close" /></div><div class="navMobileText">Close</div>
		  </div>
		  </a>
<!-- mobile menus -->
<ul id="nav"><!-- MULTI DOC MENU IF ANY --><!-- GENERIC 102 - PRE MENU ITEMS IN HAMBURGER MENU, IF ANY -->
<li><a class=" DDSMEZODLevel1Tab1" href="HTML1/default.htm" >CEO Letter to Shareholders</a>
</li>
<li><a class=" DDSMEZODLevel1Tab2" href="HTML1/financials.htm" >Select Financials</a>
</li>
<li><a class=" DDSMEZODLevel1Tab3" href="https://materials.proxyvote.com/NIKE/NPS26" >Proxy Statement</a>
</li>
<li><a class=" DDSMEZODLevel1Tab4" href="https://materials.proxyvote.com/NIKE/FORM10K26" >10-K</a>
</li>
<!-- HELP MENU -->
<li id="helpandfeatures"><a href="help.htm" aria-haspopup="true">Help &amp; Features</a><ul>
<!--ONEPDFSTART--> 
<li class="hide0 hide_ezod-kitdownloadsprintoff_"><a href="images/NIKE-Shareholder_Letter_2026.pdf" target="_blank"><div class="nav-OnePDF ddmobileicondiv"></div><div class="ddmobileicontextdiv">Download PDF</div><div class="clearfix"></div></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a href="print.htm?source=downloadbutton"><div class="nav-Download ddmobileicondiv"></div><div class="ddmobileicontextdiv">Downloads</div><div class="clearfix"></div></a></li>
<!--ONEPDFEND-->

<li class="hide0"><a href="https://www.nike.com" target="_blank"><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Company Home</div><div class="clearfix"></div></a></li>
<li class="show1"><div class="nav-Help ddmobileicondiv"></div><a href="#" aria-haspopup="true">Share</a><ul>
  <script type = "text/javascript" >

  if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') { 
  	_EZFMM51(1,'NIKE, Inc. 2026 Annual Report','','NIKE, Inc. 2026 Annual Report'); 
  } else { 
  	_EZFMM51(1,'{hosting_BtnCustom4stripped}','','{hosting_BtnCustom4stripped}'); 
  } 
</script>
</ul></li>
<li class="hide0"><a href="print.htm?p1url=&amp;p1thu=&amp;p2url=&amp;p2thu="><div class="nav-Print ddmobileicondiv"></div><div class="ddmobileicontextdiv">Print</div><div class="clearfix"></div></a></li>
<li class="show1"><a href="contents.htm"><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Clickable Index</div><div class="clearfix"></div></a></li>
<li class="show1"><a href="thumbnails.htm"><div class="nav-Thumbs ddmobileicondiv"></div><div class="ddmobileicontextdiv">Thumbnails</div><div class="clearfix"></div></a></li>
<li class="show0"><a href="accessibility.htm">Accessibility Features</a></li>
<li class="hide0"><a href="help.htm"><div class="nav-Help ddmobileicondiv"></div><div class="ddmobileicontextdiv">Help</div><div class="clearfix"></div></a></li>
<!-- <li class="show{has2PageFeature} show{has1PageURL}"><a href="{originalurl}"><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Single Page View</div><div class="clearfix"></div></a></li> -->
<!-- <li class="show{has2PageFeature} show{has2PageURL}"><a href="{twopageurl}"><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Double Page View</div><div class="clearfix"></div></a></li> -->
<!-- <li id="tilesmobilenavmenu" class="show0"><a href="javascript:_ezFH1008('{htmldir}','tiles.htm');"><div class="nav-Tiles ddmobileicondiv"></div><div class="ddmobileicontextdiv">Home Page</div><div class="clearfix"></div></a></li> -->
<!-- <li class="show1"><div class="nav-Help ddmobileicondiv"></div><a href="results.htm">Search</a></li> -->
</ul></li></ul>

<!-- mobile menus -->

         </nav>
	<div id="ezmobilebuttonstoprightdiv" class="display768orsmaller" style="float:right; margin-right:5px;">
<ul class="ulMobileItems" style="list-style-type: none;">
<li id="btnMobileMenuOffResponsive" class="libtnMenuMobileDisabled" style="display:none;"><a href="#" class="nav-MenuMobileDisabled" id="nav-MenuMobileDisabled"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Menu" title="Menu" /></a><div class="navMobileText">Menu</div></li>
<li class="libtnZoominMobile" id="smalldoubletaptext" style="display:none;"><div style="padding-left:8px;"><a href="javascript:showBigZoom();" class="nav-ZoomInMobileBig"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /></a></div><div class="navMobileText">Zoom In</div></li>
<li class="libtnZoomOutMobile" id="largedoubletaptext" style="display:none;"><div style="padding-left:12px;"><a href="javascript:hideBigZoom();" class="nav-ZoomOutMobileBig"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom Out" title="Zoom Out" /></a></div><div class="navMobileText">Zoom Out</div></li>
<li id="btnZoomOffResponsive" class="libtnZoomDisabledMobile"><div style="padding-left:8px;"><a href="#" class="nav-ZoomInMobileBigDisabled"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /></a></div><div class="navMobileText">Zoom In</div></li>

<li id="btnSearchOnResponsive" class="libtnSearchMobile show1 show{hasResultsURL}" style="margin-right:8px;"><div style="padding-left:6px;"><a href="results.htm" class="nav-SearchMobileBig"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Search" title="Search" /></a></div><div class="navMobileText">Search</div></li>
<li id="btnSearchOnCurPageResponsive" class="libtnSearchMobile show1 hide{hasResultsURL}" style="margin-right:8px;"><div style="padding-left:6px;"><a href="results.htm" class="nav-SearchMobileBigOn"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Search" title="Search" /></a></div><div class="navMobileText">Search</div></li>
<li id="btnSearchOffResponsive" class="libtnSearchMobileDisabled"  style="display:none;"><div style="padding-left:6px;"><a href="#" class="nav-SearchMobileBigDisabled"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Search" title="Search" /></a></div><div class="navMobileText">Search</div></li>

<li class="show{hasTilesURL}" id="nav-TilesIDMobile" style="display:none; margin-right:9px;"><div style="padding-left:4px;"><a href="javascript:_ezFH1008('{htmldir}','tiles.htm');" class="nav-TilesMobile" id="nav-TilesIDA"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li class="hide{hasTilesURL}" id="nav-TilesIDOnMobile" style="margin-right:9px;"><div style="padding-left:4px;"><a href="default.htm" class="nav-TilesMobileOn" id="nav-TilesIDAOn"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li id="btnTilesOffResponsive" class="libtnTilesMobileDisabled" style="display:none; margin-right:9px;"><div style="padding-left:4px;"><a class="nav-TilesMobileDisabled" id="nav-TilesMobileDisabledA"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li class="hide0 show{hasDefaultURL}" id="nav-HomeNoTilesMobileID" style="margin-right:9px;"><div style="padding-left:4px;"><a href="default.htm" class="nav-TilesMobile" id="nav-HomeNoTilesmobileIDA"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li class="hide0 hide{hasDefaultURL}" id="nav-HomeNoTilesMobileDefaultPageID" style="margin-right:9px;"><div style="padding-left:4px;"><a href="default.htm" class="nav-TilesMobileOn" id="nav-HomeNoTilesMobileDefaultPageID"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>

</ul>
</div>


</div>
<div style="display:none;" id="ezzoomlargescreenbuttons">
<div class="" style="float:right; margin-right:5px;">
<ul class="ulMobileItems" style="list-style-type: none;">
<li class="largescreenzoomminus" id="largescreenzoomminus"><div style="padding-left:14px;"><a href="javascript:hideBigZoomDesktop('{has2PageURL}','false');" class="nav-ZoomMinus"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom Out" title="Zoom Out" /></a></div><div class="navMobileText">Zoom Out</div></li>
</ul>
</div>
</div>


<div class="clearfix"></div>

</div>
</div>
</div>



<div id="ez_header" class="fullwidth display960orlarger">
<!-- DESKTOP DOC SWITCHER -->
<!-- NIKE TOGGLE BAR START  -->
<div id="nike_navtop">&nbsp;
<font color="#F47920"><b>CEO Letter to Shareholders</b>&nbsp;</font>
|&nbsp; <a href="https://materials.proxyvote.com/NIKE/NPS26" class="ez_navbartop">Proxy Statement</a> 
|&nbsp; <a href="https://materials.proxyvote.com/NIKE/FORM10K26" class="ez_navbartop">10-K</a>
</div>
<!-- NIKE TOGGLE BAR END  -->
	<div id="ez_rightbgbox"></div>
<div id="ez_logobox"></div>
<div id="ez_logo"><a href="default.htm"><img src="images/logo.png" border="0" alt="" /></a></div>
<div id="ez_titlebox">
<div id="ez_doctitle">2026 Annual Report</div>
<div id="ez_subdoctitle"></div>
</div>

</div>


<div id="eznavbox-outer" class="eznavbox-outer_ezod-kitoff_ display960orlarger"><div id="eznavbox-inner" class="eznavbox-inner_ezod-kitoff_">
<div id="ezkitlinkitems" class="container show_ezod-kitoff_ show{showdocswitchertabsflag}"><table width="100%" border="0" cellspacing="1" cellpadding="0" class="sub1">
		 		<tr class="framenav">
			<td id="doc0tab" class="framehdrbg{hosting_isCurrentDoc} show{hosting_exists}" align="center"><a id="doc0link" href="{hosting_rooturl}{htmldir}/default.htm" class="framehdrfont{hosting_isCurrentDoc}">{hosting_shortdoctitlestripped}</a></td>
			<td id="doc1tab" class="framehdrbg{doc1_isCurrentDoc} show{doc1_exists}" align="center"><a id="doc1link" href="{doc1_rooturl}{htmldir}/default.htm" class="framehdrfont{doc1_isCurrentDoc}">{doc1_shortdoctitlestripped}</a></td>
			<td id="doc2tab" class="framehdrbg{doc2_isCurrentDoc} show{doc2_exists}" align="center"><a id="doc2link" href="{doc2_rooturl}{htmldir}/default.htm" class="framehdrfont{doc2_isCurrentDoc}">{doc2_shortdoctitlestripped}</a></td>
			<td id="doc3tab" class="framehdrbg{doc3_isCurrentDoc} show{doc3_exists}" align="center"><a id="doc3link" href="{doc3_rooturl}{htmldir}/default.htm" class="framehdrfont{doc3_isCurrentDoc}">{doc3_shortdoctitlestripped}</a></td>
			<td id="doc4tab" class="framehdrbg{doc4_isCurrentDoc} show{doc4_exists}" align="center"><a id="doc4link" href="{doc4_rooturl}{htmldir}/default.htm" class="framehdrfont{doc4_isCurrentDoc}">{doc4_shortdoctitlestripped}</a></td>
			<td id="doc5tab" class="framehdrbg{doc5_isCurrentDoc} show{doc5_exists}" align="center"><a id="doc5link" href="{doc5_rooturl}{htmldir}/default.htm" class="framehdrfont{doc5_isCurrentDoc}">{doc5_shortdoctitlestripped}</a></td>
			<td id="doc6tab" class="framehdrbg{doc6_isCurrentDoc} show{doc6_exists}" align="center"><a id="doc6link" href="{doc6_rooturl}{htmldir}/default.htm" class="framehdrfont{doc6_isCurrentDoc}">{doc6_shortdoctitlestripped}</a></td>
			<td id="doc7tab" class="framehdrbg{doc7_isCurrentDoc} show{doc7_exists}" align="center"><a id="doc7link" href="{doc7_rooturl}{htmldir}/default.htm" class="framehdrfont{doc7_isCurrentDoc}">{doc7_shortdoctitlestripped}</a></td>
			<td id="doc8tab" class="framehdrbg{doc8_isCurrentDoc} show{doc8_exists}" align="center"><a id="doc8link" href="{doc8_rooturl}{htmldir}/default.htm" class="framehdrfont{doc8_isCurrentDoc}">{doc8_shortdoctitlestripped}</a></td>
			<td id="doc9tab" class="framehdrbg{doc9_isCurrentDoc} show{doc9_exists}" align="center"><a id="doc9link" href="{doc9_rooturl}{htmldir}/default.htm" class="framehdrfont{doc9_isCurrentDoc}">{doc9_shortdoctitlestripped}</a></td>
			<td id="doc10tab" class="framehdrbg{doc10_isCurrentDoc} show{doc10_exists}" align="center"><a id="doc10link" href="{doc10_rooturl}{htmldir}/default.htm" class="framehdrfont{doc10_isCurrentDoc}">{doc10_shortdoctitlestripped}</a></td>
			<td id="doc11tab" class="framehdrbg{doc11_isCurrentDoc} show{doc11_exists}" align="center"><a id="doc11link" href="{doc11_rooturl}{htmldir}/default.htm" class="framehdrfont{doc11_isCurrentDoc}">{doc11_shortdoctitlestripped}</a></td>
			<td id="doc12tab" class="framehdrbg{doc12_isCurrentDoc} show{doc12_exists}" align="center"><a id="doc12link" href="{doc12_rooturl}{htmldir}/default.htm" class="framehdrfont{doc12_isCurrentDoc}">{doc12_shortdoctitlestripped}</a></td>
			<td id="doc13tab" class="framehdrbg{doc13_isCurrentDoc} show{doc13_exists}" align="center"><a id="doc13link" href="{doc13_rooturl}{htmldir}/default.htm" class="framehdrfont{doc13_isCurrentDoc}">{doc13_shortdoctitlestripped}</a></td>
			<td id="doc14tab" class="framehdrbg{doc14_isCurrentDoc} show{doc14_exists}" align="center"><a id="doc14link" href="{doc14_rooturl}{htmldir}/default.htm" class="framehdrfont{doc14_isCurrentDoc}">{doc14_shortdoctitlestripped}</a></td>
			<td id="doc15tab" class="framehdrbg{doc15_isCurrentDoc} show{doc15_exists}" align="center"><a id="doc15link" href="{doc15_rooturl}{htmldir}/default.htm" class="framehdrfont{doc15_isCurrentDoc}">{doc15_shortdoctitlestripped}</a></td>
		</tr>
		</table></div>	
<div id="ez_navbox">
	<div id="ez_commandmenubox"><div id="ez_row1box" class="container"><div id="ez_row1paddingdiv">
		
<span class="ezod_commandicons"> 
<ul>

<li class="show{hasTilesURL}" id="nav-TilesID" style="display:none;"><a href="javascript:_ezFH1008('{htmldir}','tiles.htm');" class="nav-Tiles" id="nav-TilesIDA"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<li class="hide{hasTilesURL}" id="nav-TilesIDOn"><a href="default.htm" class="nav-TilesOn" id="nav-TilesIDAOn"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<li class="hide0 show{hasDefaultURL}" id="nav-HomeNoTilesID"><a href="default.htm" class="nav-Tiles" id="nav-HomeIDA"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<li class="hide0 hide{hasDefaultURL}" id="nav-HomeNoTilesOnID"><a href="default.htm" class="nav-TilesOn" id="nav-HomeOnIDA"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<!--ONEPDFSTART--> 
<!--
<li class="hide0 hide_ezod-kitdownloadsprintoff_"><a href="images/NIKE-Shareholder_Letter_2026.pdf" class="hide0 nav-OnePDF" target="_blank"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Download PDF" title="Download PDF" /><span>Download PDF</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide{hasPrintURL} nav-DownloadDisabled" id="nav-DownloadIsCurrentPageDisabled-Top"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide{hasPrintURL} show{hasPrintURL} nav-DownloadOn" id="nav-DownloadIsCurrentPageOn-Top"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a href="print.htm?source=downloadbutton" class="show{hasPrintURL} nav-Download"  id="nav-DownloadNormal-Top"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Downloads" title="Downloads" /><span>Downloads</span></a></li>
-->
<!--ONEPDFEND-->

<li class="hide0"><script type="text/javascript">
//<![CDATA[
if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF11Sprite(1,'NIKE, Inc. 2026 Annual Report','');
} else {
	_EZF11Sprite(1,'{hosting_BtnCustom4stripped}','');
}
//]]>
</script>
<script type="text/javascript">
//<![CDATA[ 
if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF51(0,'NIKE, Inc. 2026 Annual Report','','NIKE, Inc. 2026 Annual Report');
} else {
	_EZF51(0,'{hosting_BtnCustom4stripped}','','{hosting_BtnCustom4stripped}');
}
//]]>
</script>

</li>
<li class="hide0"><a class="hide{hasPrintURL} nav-PrintOn" id="nav-PrintIsCurrentPageOn-Top"><span>Print</span></a></li>
<li class="hide0"><a class="hide{hasPrintURL} show{hasPrintURL} nav-PrintDisabled" id="nav-PrintIsCurrentPageDisabled-Top"><span>Print</span></a></li>
<li class="hide0"><a href="print.htm?p1url=&amp;p1thu=&amp;p2url=&amp;p2thu=" class="show{hasPrintURL} nav-Print" id="nav-PrintNormal-Top"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Print" title="Print" /><span>Print</span></a></li>
<li class="show1"><a class="hide{hasClickableIndexURL} nav-IndexOn"><span>Clickable Index</span></a></li>
<li class="show1"><a href="contents.htm" class="show{hasClickableIndexURL} nav-Index"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Clickable Index" title="Clickable Index" /><span>Clickable Index</span></a></li>
<li class="show1"><a class="hide{hasThumbnailURL} nav-ThumbsOn"><span>Thumbnails</span></a></li>
<li class="show1"><a href="thumbnails.htm" class="show{hasThumbnailURL} nav-Thumbs"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Thumbnails" title="Thumbnails" /><span>Thumbnails</span></a></li>
<!--
<li class="hide0 show{has2PageURL} display1200orsmaller largescreenzoomplus" id="largescreenzoomplus" style="display:none;"><a href="javascript:showBigZoomDesktop('{has2PageURL}','false');" class="nav-ZoomPlus"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 hide{has2PageURL} largescreenzoomplus" id="largescreenzoomplustwopage" style="display:none;"><a href="javascript:showBigZoomDesktop('{has2PageURL}','false');" class="nav-ZoomPlus"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 largescreenzoomplusdisabled display1200orsmaller" id="largescreenzoomplusdisabled" style=""><a href="#" class="nav-ZoomPlusDisabled"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
-->


<li class="hide0"><a class="hide{hasHelpURL} nav-HelpOn"><span>Help</span></a></li>
<li class="hide0"><a href="help.htm" class="show{hasHelpURL} nav-Help"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Help" title="Help" /><span>Help</span></a></li>
</ul>
<script type="text/javascript">
//<![CDATA[
_EZF39Div();
if (_ez60 == 0) {
	_EZF01();
	document.write('<div class="searchdiv"><form class="zzez_searchbox ez_searchboxtopform" id="jse_Form1" name="jse_Form1" method="get" action="' + _ez01 + '" onsubmit="return _EZF02(\'d1\');"><ul>');
	_EZF13_Sprite(1);
	document.write('</ul><div class="clearfix" style="clear:both;"></div></form></div>');
}
//]]>
</script>
	</span>
<span class="ezod_pin" style="display:none;visibility:hidden;">
	<div class="ez_pindiv show1 hide0">
<ul class="ulPinItems">
<li class="libtnPinOn"><a onclick="_ezFH1003(false);" class="nav-PinOn"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Unpin Menu Bar" title="Unpin Menu Bar" /><span>Unpin Menu Bar</span></a></li>
<li class="libtnPinOff"><a onclick="_ezFH1003(true);" class="nav-Pin"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Pin Menu Bar" title="Pin Menu Bar" /><span>Pin Menu Bar</span></a></li>
</ul>
</div>
</span>
<span class="ezod_linearnavigation" id="LinearNavSpanTop">
<div class="ez_pageprevnexttop">
<ul>
<li class="hide0 show0 show{hasTilesURL}"><a href="javascript:_ezFH1008('{htmldir}','tiles.htm');" class="nav-PrevPage"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="hide0 hide0"><a class="hide0 nav-PrevPageDisabled"><span>Go to previous page</span></a></li>
<li class="hide0 hide{hasTilesURL}"><a class="hide0 nav-PrevPageDisabled"><span>Go to previous page</span></a></li>
<li class="show0"><a href="HTML1/financials.htm" class="show0 nav-PrevPage"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="show0"><a href="{nexturl}" class="show0 nav-NextPage"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
<li class="hide0 show{hasTilesURL}"><a class="hide0 nav-NextPageDisabled"><span>Go to next page</span></a></li>
<li class="hide0 hide{hasTilesURL}"><a href="HTML1/default.htm" class="nav-NextPage"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
</ul>
</div>

<script type="text/javascript" src="Text/jse_pdfpagenumbering.js"></script>
<script type="text/javascript">
//<![CDATA[
write_dropdownmenudiv('');
//]]>
</script>


</span>

</div></div></div>
<div id="ez_menuboxouter">
<div id="ez_menubox" class="container"><ul id="qm0" class="qmmc">
<li><a class="qmparent EZODLevel1Tab1" href="HTML1/default.htm" ><span>CEO Letter to Shareholders</span></a>
</li>
<li><a class="qmparent EZODLevel1Tab2" href="HTML1/financials.htm" ><span>Select Financials</span></a>
</li>
<li><a class=" EZODLevel1Tab3" href="https://materials.proxyvote.com/NIKE/NPS26" ><span>Proxy Statement</span></a>
</li>
<li><a class=" EZODLevel1Tab4" href="https://materials.proxyvote.com/NIKE/FORM10K26" ><span>10-&#8203;K</span></a>
</li>
<li class="qmclear">&nbsp;</li></ul>

<script type="text/javascript">qm_create(0,false,0,500,false,false,false,false,false);</script>
</div><div id="ez_mobilemenubox" class="container" style="display:none;"><ul id="qm1" class="qmmc">
<li><a class="qmparent EZODLevel1Tab1" href="HTML1/default.htm" ><span>CEO Letter to Shareholders</span></a>
</li>
<li><a class="qmparent EZODLevel1Tab2" href="HTML1/financials.htm" ><span>Select Financials</span></a>
</li>
<li><a class=" EZODLevel1Tab3" href="https://materials.proxyvote.com/NIKE/NPS26" ><span>Proxy Statement</span></a>
</li>
<li><a class=" EZODLevel1Tab4" href="https://materials.proxyvote.com/NIKE/FORM10K26" ><span>10-&#8203;K</span></a>
</li>
<li class="qmclear">&nbsp;</li></ul>

<script type="text/javascript">qm_create(1,false,0,500,false,false,false,false,false);</script>
</div>
</div>


<script type="text/javascript">
//<![CDATA[
_EZF202(); 
//]]>
</script>
</div>
</div>
</div>

<div id="ez_contentbox" class="ez_contentbox{htmldir}"><table id="ez_containerbox" cellpadding="0" cellspacing="0"><tr><td>
	
<div id="ez_documentbox" class="visibleitem fullwidth"><div id="ContentDiv" class="show1">
<script type="text/javascript">
//<![CDATA[
_EZF45();
//]]>
</script>
<div class="clearfix"></div>
<div class="hide1 show{has2PageFeature} ez_prevcontinuediv" id="ez_dblpagebuttondivtop" style="display:none;">
<div style="text-align:center; height:23px;" class="ez_LargeBtnContinueDiv">
<span class="show{has2PageFeature}">
<span class="show{has1PageURL}"><a href="{originalurl}" class="nav-SinglePageView" id="nav-SinglePageViewA"><img src="images/blank.gif" class="blankgifspacerpageview" alt="Single Page View" title="Single Page View" /><span>Single Page View</span></a></span>
<span class="show{has2PageURL}"><a href="{twopageurl}" class="nav-DoublePageView" id="nav-DoublePageViewA"><img src="images/blank.gif" class="blankgifspacerpageview" alt="Double Page View" title="Double Page View" /><span>Double Page View</span></a></span>
</span>
</div>
</div>

<script>
if ('false' == 'true' && '{has2PageFeature}' == '1') {
	$('#ez_dblpagebuttondivtop').show();
}
</script>

<!-- ApplyTemplate: Yes -->
<!-- ImageWidthReplacement: 777 -->
<style type="text/css">
	#ez_documentbox { background-color:white !important; }
	#ez_footerbox { visibility: hidden !important; display: none !important; }
	#ez_row1paddingdiv { visibility: hidden !important; display: none !important; }
	#ez_menubox { visibility: hidden !important; display: none !important; }
	#ez_mobilemenubox { visibility: hidden !important; display: none !important; }
	#ez_navbartopbox { visibility: hidden !important; display: none !important; }
	#ez_interactivemenubox { visibility: hidden !important; display: none !important; }
	#JSOffFooter { visibility: hidden !important; display: none !important; }
/*
	#ez_header { width:777px; }
	#ez_documentbox { width:777px; }
	#ez_navbartopoutbox { 	width:777px; }
	#ez_docfooterbox { min-width: 777px; }
	#ez_footerbox { width:777px;} 
	*/
</style>

<script type="text/javascript">
//<![CDATA[
BrowserDetection.init(true);

if (!oldBrowser) {

var _ez64=0; 
var _ez65=1;
var _ez66=0; 
var _ez94 = 0;
var _ez95 = 0;
var _ez96 = 0;
var _ez97 = '';
var _ez98 = ',1,';
var _ezT01 = 0;
var _ezT02 = 0;
var _ezT03 = 1;
var _ezT11 = 0;
var _ezSE01 = 0;
var _ezT04 = 1;
var _ezT13 = 0;
var _ezPI01 = 0;
var _ezPI02 = 1;
var _ezPI03 = 0;
var _ezPI04 = 0;
var _ezPI05 = 1;
var _ezPI06 = 0;
var _ezFH01 = 1;
var _ezFH02 = 801;
var _ezSh01 = 1;
var _ezSh02 = 1;
var _ezSh03 = 1;
var _ezSh04 = 1;
var _ezSh05 = 0;
var _ezSh06 = '';
var _ezB07 = '';
var _ezB08 = '';
var _ezB09 = '';
var _ezB10 = '';
var _ezB11 = '';
var _ezB31 = 0;
var _ezB36 = 0;
var _ezB37 = ',1,';
var _ezB46 = 0;
var _ezB47 = 0;
var _ezB48 = 0;
var _ezB49 = 0;
var _ezB50 = 0;
var _ezB51 = 0;
var _ezB52 = 960;
var _ezB53 = 1200;
var _ezB54 = 0;


if (_ezT11 == 1) { //If is in a kit, and kit has tiles, turn tiles on
	//Replaceables get set in Kits, but not in non-kits, leaving non-kit jobs alone
	 if ("{hosting_KitEzTilesMobileFlag}" == "Y") {
	 		_ezT01 = 1;
	 } else if ("{hosting_KitEzTilesMobileFlag}" == "N") {
	 	_ezT01 = 0;
	}
	
		 if ("{hosting_KitEzTilesDesktopFlag}" == "Y") {
	 		_ezT02 = 1;
	 } else if ("{hosting_KitEzTilesDesktopFlag}" == "N") {
	 	_ezT02 = 0;
	}
	
		 if ("{hosting_KitEzTilesMobile_OpenOnFirstPageFlag}" == "Y") {
		 	//Now turn off tiles if a subjob on hosting job, just go to the first page normally - only hosting job gets tiles automatically
				if ("{hosting_isCurrentDoc}" != "1") {
					_ezT03 = 0;
				} else {
	 			_ezT03 = 1;
	 			}
	 } else if ("{hosting_KitEzTilesMobile_OpenOnFirstPageFlag}" == "N") {
	 	_ezT03 = 0;
	}
		 if ("{hosting_KitEzTilesDesktop_OpenOnFirstPageFlag}" == "Y") {
	 		if ("{hosting_isCurrentDoc}" != "1") {
					_ezT04 = 0;
			} else {
	 			_ezT04 = 1;
	 		}
	 } else if ("{hosting_KitEzTilesDesktop_OpenOnFirstPageFlag}" == "N") {
	 	_ezT04 = 0;
	}
	
	
	
}

	_ez28 = screen.availWidth;
	_ezFH29 = screen.availHeight;

var _ezshowtiles = false;
if (typeof _ezT02 != 'undefined') {	
	var ezt_mobile = (/ipad|iphone|ipod|android|blackberry|mini|windows\sce|palm|touchpad/i.test(navigator.userAgent.toLowerCase()));  
	if (_ezT01 == 1 && _ezT03 == 1 && ezt_mobile) { //if mobile tiles on, and mobile open on first page, and is mobile
		_ezshowtiles = true;
	}
	if (_ezT02 == 1 && _ezT04 == 1 && !ezt_mobile) { //if desktop tiles on, and desktop open on first page, and is desktop
		_ezshowtiles = true;
	}
}


//Send you back up to parent tiles, if in a kit sub job and should be using parent tiles
var parentdirectoryifneeded = '';
if (_ezshowtiles) {
	if (_ezT11 == 1 && "{kit_iskitjob}" == "Y") { //Kit job, using parent tiles
			parentdirectoryifneeded = '{hosting_rooturl}';
	}
}

/*

the existing "Starting in HTML1 res" will determine if it is HTML1 or HTML2
Then if "Start in 2page mode" is picked, you pick the right 2 page mode (see above for that logic)
NOTE: Neither of those checkboxes is checked by default, so the job should start up in HTML2 single page view by default
*/

var _ezdefaultpagename = 'default';
if (_ezshowtiles) {
	_ezdefaultpagename = 'tiles';
}

if (_ezB50 == 1) { //Start in two page
	location.href = parentdirectoryifneeded + 'HTML1/' + _ezdefaultpagename + '-twopage.htm'; 
} else { //Don't start in two page
	location.href = parentdirectoryifneeded + 'HTML1/' + _ezdefaultpagename + '.htm';
}

}
//]]>
</script>

<div style="background-color:white;  font-size:16px;">
<br />

<!--ONEPDFSTART--> 
<div class="container">
<div class="six columns">
<div style="padding-left:3px; padding-right:3px; text-align:center;">
<noscript>
<p><a href="images/NIKE-Shareholder_Letter_2026.pdf" target="_blank"><img src="Thumbs/thumb_firstpage.jpg" border="0" height="195" width="150" alt="Click here to download this document" title="Click here to download this document" /></a></p>
</noscript>
<script type="text/javascript">

if (_ez18 < 5) {
	document.write('<a href="images/NIKE-Shareholder_Letter_2026.pdf" target="_blank"><img src="Thumbs/thumb_firstpage.jpg" style="max-width:48%;"  border="0" alt="' + _ez30[5] + ' ' + _ez30[4] + '" title="' + _ez30[5] + ' ' + _ez30[4] + '"></a>');
	if (_ez16 > 1) {

		document.write('<a href="images/NIKE-Shareholder_Letter_2026.pdf" target="_blank"><img src="Thumbs/thumb_lastpage.jpg" style="max-width:48%;"  border="0"  alt="' + _ez30[5] + ' ' + _ez30[4] + '" title="' + _ez30[5] + ' ' + _ez30[4] + '"></a>');
	}
} else {
	document.write('<a href="images/NIKE-Shareholder_Letter_2026.pdf" class="box" target="_blank"><img src="Thumbs/thumb_firstpage.jpg" style="max-width:48%;"  border="0" alt="' + _ez30[5] + ' ' + _ez30[4] + '" title="' + _ez30[5] + ' ' + _ez30[4] + '"></a>');
	if (_ez16 > 1) {
		document.write('<a href="images/NIKE-Shareholder_Letter_2026.pdf" class="box" target="_blank"><img src="Thumbs/thumb_lastpage.jpg" style="max-width:48%;"  border="0"  alt="' + _ez30[5] + ' ' + _ez30[4] + '" title="' + _ez30[5] + ' ' + _ez30[4] + '"></a>');
	}
}

</script>
</div>
</div>


<div class="nine columns">
<div style="padding-left:3px; padding-right:3px;">
<h2 class="showpr_ezod-kitoff_">Print Entire Document</h2>
<h2 class="hidepr_ezod-kitoff_">Print 2026 Annual Report</h2>
<a href="images/NIKE-Shareholder_Letter_2026.pdf" target="_blank">Click here</a> to download a printable version of this entire document. After the document downloads, you can print it or save it for future reference.
</div>
</div>
</div>
<!--ONEPDFEND-->



</div>

<div class="tablecontainer">
 
<table  class="fullwidth" cellspacing="0" cellpadding="0" class="main" align="center">
<tr><td>
	<table  class="fullwidth" align="center" cellspacing="0" cellpadding="0"> 

	<tr><td align="center" bgcolor="white">

		<table width="85%"><tr><td valign="top">


<script type="text/javascript">
//<![CDATA[
document.write(_ez30[87] + ' <a href="HTML1/default.htm">' + _ez30[88] + '</A>.');
//]]>
</script>

<noscript>
<br /><table width="100%" bgcolor="white"><tr><td width="130">
	<img src="images/warning_english.jpg" alt="WARNING" title="WARNING" width="115" height="115" />
	
</td><td valign=top style="font-size:16px;">
<h2>JavaScript is disabled</h2>
JavaScript is required to view this online document. You can use the PDF (see above) or enable JavaScript in your browser.
<br /><br />



</td></tr></table>
<br /><br />


<!--ONEPDFSTART-->
<!-- {  Generic3  }  -->
<!--ONEPDFEND-->
<span class="accessible">
	If you see a message at the top of your browser such as "... restricted this file from showing active content," then you can click for options and pick "Allow Blocked Content." If asked, you can confirm "Yes" to allow the page to run active content. The content being blocked is navigation and searching functions for this document.
</span>
<br /><br />

</noscript>



		</td></tr>
		</table>



		</td></tr>
		</table>

</td></tr>
</table>

<div class="PDF-Footer" style="position:relative; padding:12px 12px 12px 12px;">
<a href="http://get.adobe.com/reader/" target="_blank"><img src="images/get_adobe_reader.jpg" border="0" align="left" style="margin-right:20px;" alt="Adobe Reader" /></a>
Printable versions of documents are provided in Adobe Portable Document Format. To receive free software to read these documents, visit Adobe's site to download and install Adobe Acrobat Reader
<a href="http://get.adobe.com/reader/" target="_blank">click here</a>.<div style="clear:both;"></div>
</div>


</div>
<div class="display960orlarger">
<div class="hide1 hide0 ez_prevcontinuediv" id="ez_prevcontinuedivbottom">
<div style="width:20%; float:left; height:23px; text-align:left;" class="continue">
<span class="hide0"><span class="showcont0">&nbsp;&nbsp;&nbsp;<a href="HTML1/financials.htm" class="continue">...Previous</a></span></span>
</div>
<div style="width:80%; float:right; height:23px;">
<div style="width:25%; float: right; height:23px; text-align:right;" class="continue">
<span class="hide0"><span class="showcont0"><a href="{nexturl}" class="continue">Continue...</a>&nbsp;&nbsp;&nbsp;</span></span>
</div>
</div>
</div>

</div>
</div></div>

</td></tr></table></div>




<script>
$(function(){

	
	if ('{hasTilesURL}' == '0') {
		$('#mobilefooterpagetotal').hide();
	}

	if ('0' == '0' && '{hasTilesURL}' != '0' ) {
		$('#ez_mobilefooter').hide();
	} else {

	}
   
});

</script>


<div id="ez_docfooterbox" class="fullwidth display960orlarger"><div id="ez_footerbox" class="fullwidth"><div id="ez_bottomrightbgbox"></div> 
<div id="ez_row4box"><div id="ez_row4paddingdiv">				
<span class="ezod_commandicons"> 
<ul>

<li class="show{hasTilesURL}" id="nav-TilesIDBottom" style="display:none;"><a href="javascript:_ezFH1008('{htmldir}','tiles.htm');" class="nav-TilesBottom" id="nav-TilesIDBottomA"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Tiles" title="Tiles" /><span>Tiles</span></a></li>
<li class="hide{hasTilesURL}" id="nav-TilesIDBottomOn"><a href="default.htm" class="nav-TilesBottomOn" id="nav-TilesIDBottomAOn"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Tiles" title="Tiles" /><span>Tiles</span></a></li>
<!--ONEPDFSTART--> 
<li class="hide0 hide_ezod-kitdownloadsprintoff_"><a href="images/NIKE-Shareholder_Letter_2026.pdf" class="hide0 nav-OnePDFBottom" target="_blank"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Download PDF" title="Download PDF" /><span>Download PDF</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide{hasPrintURL} nav-DownloadBottomDisabled" id="nav-DownloadIsCurrentPageDisabled-Bottom"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide{hasPrintURL} show{hasPrintURL} nav-DownloadBottomOn" id="nav-DownloadIsCurrentPageOn-Bottom"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a href="print.htm?source=downloadbutton" class="show{hasPrintURL} nav-DownloadBottom" id="nav-DownloadNormal-Bottom"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Downloads" title="Downloads" /><span>Downloads</span></a></li>
<!--ONEPDFEND-->

<li class="hide0"><script type="text/javascript">
//<![CDATA[
if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF11Sprite(2,'NIKE, Inc. 2026 Annual Report','');
} else {
	_EZF11Sprite(2,'{hosting_BtnCustom4stripped}','');
}
//]]>
</script>
<script type="text/javascript">
//<![CDATA[ 
	if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF51(1,'NIKE, Inc. 2026 Annual Report','','NIKE, Inc. 2026 Annual Report');
} else {
	_EZF51(1,'{hosting_BtnCustom4stripped}','','{hosting_BtnCustom4stripped}');
}
//]]>
</script>
</li>
<li class="hide0"><a class="hide{hasPrintURL} nav-PrintBottomOn" id="nav-PrintIsCurrentPageOn-Bottom"><span>Print</span></a></li>
<li class="hide0"><a class="hide{hasPrintURL} show{hasPrintURL} nav-PrintBottomDisabled" id="nav-PrintIsCurrentPageDisabled-Bottom"><span>Print</span></a></li>
<li class="hide0"><a href="print.htm?p1url=&amp;p1thu=&amp;p2url=&amp;p2thu=" class="show{hasPrintURL} nav-PrintBottom" id="nav-PrintNormal-Bottom"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Print" title="Print" /><span>Print</span></a></li>
<li class="show1"><a class="hide{hasClickableIndexURL} nav-IndexBottomOn"><span>Clickable Index</span></a></li>
<li class="show1"><a href="contents.htm" class="show{hasClickableIndexURL} nav-IndexBottom"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Clickable Index" title="Clickable Index" /><span>Clickable Index</span></a></li>
<li class="show1"><a class="hide{hasThumbnailURL} nav-ThumbsBottomOn"><span>Thumbnails</span></a></li>
<li class="show1"><a href="thumbnails.htm" class="show{hasThumbnailURL} nav-ThumbsBottom"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Thumbnails" title="Thumbnails" /><span>Thumbnails</span></a></li>
<li class="hide0 show{has2PageURL} display1200orsmaller largescreenzoomplus" id="largescreenzoomplusbottom" style="display:none;"><a href="javascript:showBigZoomDesktop('{has2PageURL}','false');" class="nav-ZoomPlusBottom"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 hide{has2PageURL} largescreenzoomplus" id="largescreenzoomplustwopagebottom" style="display:none;"><a href="javascript:showBigZoomDesktop('{has2PageURL}','false');" class="nav-ZoomPlusBottom"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 largescreenzoomplusdisabled display1200orsmaller" id="largescreenzoomplusdisabledbottom" style=""><a href="#" class="nav-ZoomPlusBottomDisabled"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>

<li class="hide0"><a class="hide{hasHelpURL} nav-HelpBottomOn"><span>Help</span></a></li>
<li class="hide0"><a href="help.htm" class="show{hasHelpURL} nav-HelpBottom"><img src="images/blank.gif" class="blankgifspacerbuttons" alt="Help" title="Help" /><span>Help</span></a></li>
</ul>

<script type="text/javascript">
//<![CDATA[
if (_ez60 == 0) {
	_EZF01();
	document.write('<div class="searchdiv"><form class=""ez_searchbox"" id="jse_Form2" name="jse_Form2" method="get" action="' + _ez01 + '" onsubmit="return _EZF02(\'d2\');">');
	_EZF13_Sprite(2);
	document.write('</form></div>');
}
//]]>
</script>
</span>
<span class="ezod_linearnavigation" id="LinearNavSpanBottom">
<div class="ez_pageprevnextbottom">
<ul>
<li class="hide0 show0 show{hasTilesURL}"><a href="javascript:_ezFH1008('{htmldir}','tiles.htm');" class="nav-PrevPageBottom"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="hide0 hide0"><a class="hide0 nav-PrevPageBottomDisabled"><span>Go to previous page</span></a></li>
<li class="hide0 hide{hasTilesURL}"><a class="hide0 nav-PrevPageBottomDisabled"><span>Go to previous page</span></a></li>
<li class="show0"><a href="HTML1/financials.htm" class="show0 nav-PrevPageBottom"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="show0"><a href="{nexturl}" class="show0 nav-NextPageBottom"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
<li class="hide0 show{hasTilesURL}"><a class="hide0 nav-NextPageBottomDisabled"><span>Go to next page</span></a></li>
<li class="hide0 hide{hasTilesURL}"><a href="HTML1/default.htm" class="nav-NextPageBottom"><img src="images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
</ul>
</div>


<script type="text/javascript" src="Text/jse_pdfpagenumbering.js"></script>
<script type="text/javascript">
//<![CDATA[
write_dropdownmenudiv('');
//]]>
</script>


</span>

</div></div></div> 

<style>
#ez_menubox .EZ_hasThirdLevelMenu::after, #ez_mobilemenubox .EZ_hasThirdLevelMenu::after { content: '\00A0\00BB'; float:right; position: absolute; top: 2px; right: 2px; }
/* must be in HTML or chrome breaks */
</style>

<script type="text/javascript">
$(function() {
_EZF62(); // FrameKit
_EZF110(); // Tiles
setPageURLCookie(); //Page Cookie
setMobileReturnURL('#mobilelogolink');
setMobileReturnURL('#desklogolink');
$("[class^=EZODLevel3Container]").prev().addClass('EZ_hasThirdLevelMenu');
});
</script>


</div>
</div>

<div class="container ezfootercontainer">
<div class="ezfooterbox-left">
<div id="ez_navbartopbox" class="display960orlarger"><div id="ez_navbartop">		
<hr class="ez_navbar_hr" />			
<span class="hide0"><a href="https://www.nike.com" class="ez_navbartop" target="_blank">Company Home</a>|&nbsp;</span>					

<!--ONEPDFSTART--> 
<span class="show0"><a href="accessibility.htm" class="ez_navbartop">Accessibility Features</a>|&nbsp;</span>
<span class="hide0"><a href="images/NIKE-Shareholder_Letter_2026.pdf" class="ez_navbartop" target="_blank">Download PDF</a>|&nbsp;</span>
<!--ONEPDFEND-->
<span class="hide0"><a href="print.htm?p1url=&amp;p1thu=&amp;p2url=&amp;p2thu=" class="ez_navbartop">Print</a>|&nbsp;</span>
<span class="hide0"><a href="help.htm" class="ez_navbartop">Help</a></span>

  
<hr class="ez_navbar_hr" />
</div></div>


</div>
<div class="ezfooterbox-right">
<!-- REMOVED -->
</div>
</div>

<div id="JSOffFooter" class="JSOffFooter" style="display:block; width:750px;">
WARNING: JavaScript is disabled. <a href="../default.htm">CLICK HERE</a> for help.
<br />
</div>
<div id="BrowserCheckFooter" class="BrowserCheckFooter"  style="display:none; width:750px;">
<div style="padding-left:30px; padding-right:30px; text-align:left;">
<a href="http://www.ezonlinedocuments.com/browserupgrade.aspx?lang=english" target="_blank">Click here</a> for a list of supported browsers.
</div>
<br />
</div>

<script type="text/javascript">
//<![CDATA[
document.getElementById('JSOffFooter').style.display="none";
BrowserDetection.init(false);
if (oldBrowser) {
	document.getElementById('BrowserCheckFooter').style.display="block";
}
//]]>
</script>

<div class="ezpush"></div>
</div>
<div id="ez_mobilefooter" class="clearfix display768orsmaller ezfooter hide0" style="display: block; width:100%; height:28px;">
	<div class="container clearfix" style="width: 100%;">
		
		<div style="float:left; width:20%; height:28px;" onClick="prevPage();">
		<div style="width:12px; float:left; padding-top:5px; padding-left:5px;">
<ul style="list-style-type: none; margin: 0; padding: 0;">
<li class="hide0 show0 show{hasTilesURL}"><a href="javascript:_ezFH1008('{htmldir}','tiles.htm');" class="nav-PrevPageMobile"><img src="images/blank.gif"  alt="Go to previous page" title="Go to previous page" /></a></li>
<li class="show0"><a href="HTML1/financials.htm" class="show0 nav-PrevPageMobile"><img src="images/blank.gif"  alt="Go to previous page" title="Go to previous page" /></a></li>
</ul>
</div>
<div class="navMobileText show0" style="float:left; width:30px; padding-top:9px; padding-left:2px;"><a href="HTML1/financials.htm" style="text-decoration:none;">Prev</a></div>
<div class="navMobileText hide0" style="float:left; width:30px; padding-top:9px; padding-left:2px;"><a href="tiles.htm" class="show0 show{hasTilesURL}" style="text-decoration:none;">Prev</a></div>
<div class="clearfix"></div>
</div>
		
<div style="float:left; width:60%; height:28px;"><div id="mobilefooterpagetotal" style="">Page&nbsp;0&nbsp;of&nbsp;2</div></div>


<div style="float:right; width:20%; height:28px;" onClick="nextPage();">
		<div style="width:12px; float:right; padding-top:5px; padding-right:5px; padding-left:5px;">
<ul style="list-style-type: none; margin: 0; padding: 0;">
<li class="show0"><a href="{nexturl}" class="show0 nav-NextPageMobile"><img src="images/blank.gif" alt="Go to next page" title="Go to next page" /></a></li>
<li class="hide0 hide{hasTilesURL}"><a href="default.htm" class="nav-NextPageMobile"><img src="images/blank.gif" alt="Go to next page" title="Go to next page" /></a></li>
</ul>
</div>
<div class="navMobileText show0" style="float:right; width:25px; padding-top:9px;"><a href="{nexturl}" style="text-decoration:none;">Next</a></div>
<div class="navMobileText hide0 hide{hasTilesURL}" style="float:right; width:25px; padding-top:9px;"><a href="HTML1/default.htm" style="text-decoration:none;">Next</a></div>
<div class="clearfix"></div>
</div>

<script>
function nextPage() {
if ('{hasTilesURL}' == '0') {
location.href = 'HTML1/default.htm';
} else if ('0' == '1' ) {
location.href = '{nexturl}';
}

}

function prevPage() {
if ('0' == '0' && '0' == '1' && '{hasTilesURL}' == '1' ) {
_ezFH1008('{htmldir}','tiles.htm');
} else if ('0' == '1' ) {
location.href = 'HTML1/financials.htm';
}

}

</script>

</div>
</div>



</body>
</html>

