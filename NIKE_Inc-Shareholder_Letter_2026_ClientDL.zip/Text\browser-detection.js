var notSupportedBrowsers = [{'os': 'Any', 'browser': 'MSIE', 'version': 5.5, 'versionmin': 0.0}, {'os': 'Any', 'browser': 'Firefox', 'version': 2.9, 'versionmin': 0.0}, {'os': 'Any', 'browser': 'Firefox', 'version': 3.59, 'versionmin': 3.1}, {'os': 'Any', 'browser': 'Netscape', 'version': 'Any', 'versionmin': 0.0}, {'os': 'Any', 'browser': 'Opera', 'version': 11.5, 'versionmin': 0.0}, {'os': 'Any', 'browser': 'Safari', 'version': 4.9, 'versionmin': 0.0}, {'os': 'Any', 'browser': 'Chrome', 'version': 13.9, 'versionmin': 0.0}];
var oldBrowser = false;

var BrowserDetection = {
	init: function(Redirect){		
		this.browser = this.searchString(this.dataBrowser) || "Unknown";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "1000";
		this.os = this.searchString(this.dataOS) || "Unknown";
		//alert(this.version + 'AppVersion: ' + navigator.appVersion + ' UserAgent: ' + navigator.userAgent);
		if (this.browser == 'Opera' && this.version == '1000') {
			this.versionSearchString = 'Opera';
			this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "1000";
		}
		
		if(this.browser == '' || this.browser == 'Unknown' || this.version == '' || this.version == 0)
		{
			return;
		}
		
		// Check if this is old browser
		
		for(var i = 0; i < notSupportedBrowsers.length; i++){
			if(notSupportedBrowsers[i].os == 'Any' || notSupportedBrowsers[i].os == this.os){
				if(notSupportedBrowsers[i].browser == 'Any' || notSupportedBrowsers[i].browser == this.browser){
					if(notSupportedBrowsers[i].version == "Any" || (this.version <= parseFloat(notSupportedBrowsers[i].version) && this.version >= parseFloat(notSupportedBrowsers[i].versionmin))  ){
						oldBrowser = true;
						break;
					}
				} 
			}
		}
		
		if(oldBrowser && Redirect){
			location.href = 'HTML1/browserupgrade.htm'; 
			//this.displayNotice();
		}
	},
	
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		var versionnumber = dataString.substring(index+this.versionSearchString.length+1);
		//alert(versionnumber);
		for (var x=1; x<versionnumber.length - 1; x++) { //Remove any crap after the version number
			currentchar = dataString.substring(x, x+1);
			if (currentchar == '/' || currentchar == ' ' || currentchar == '[' || currentchar == '\\') {
				versionnumber = versionnumber.substring(0, x);
				break;
		  }
		}
		
		return parseFloat(versionnumber);
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{ 	string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera",
			versionSearch: "Version"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "MSIE",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]

};

