// BEGIN:  QuickMenuPro Menu

	dqm__maindesc0 = "CEO Letter to Shareholders"
	dqm__url0 = "default.htm"

	dqm__maindesc1 = "Select Financials"
	dqm__url1 = "financials.htm"

	dqm__maindesc2 = "Proxy Statement"
	dqm__url2 = "https://materials.proxyvote.com/NIKE/NPS26"

	dqm__maindesc3 = "10-K"
	dqm__url3 = "https://materials.proxyvote.com/NIKE/FORM10K26"

// END:  QuickMenuPro Menu 

var MENU_ITEMS0 = [
	[[_EZF48(dqm__maindesc0,1,1,'','',1,0,0,0),_EZF48(dqm__maindesc0,1,1,'','Y',1,0,0,0)], dqm__url0, {'sb':dqm__maindesc0, 'sw':_ez33[0], 'xbt':_ez37, 'bw':_ez31[0], 'bl': 0 - _ez34[0] + _ez33[0]}
],
	[[_EZF48(dqm__maindesc1,1,2,'','',2,0,0,0),_EZF48(dqm__maindesc1,1,2,'','Y',2,0,0,0)], dqm__url1, {'sb':dqm__maindesc1, 'sw':_ez33[1], 'xbt':_ez37, 'bw':_ez31[1], 'bl': 0 - _ez34[1] + _ez33[1]}
],
	[[_EZF48(dqm__maindesc2,1,3,'','',3,0,0,0),_EZF48(dqm__maindesc2,1,3,'','Y',3,0,0,0)], dqm__url2, {'sb':dqm__maindesc2, 'sw':_ez33[2], 'xbt':_ez37, 'bw':_ez31[2], 'bl': 0 - _ez34[2] + _ez33[2]}
],
	[[_EZF48(dqm__maindesc3,1,4,'','',4,0,0,0),_EZF48(dqm__maindesc3,1,4,'','Y',4,0,0,0)], dqm__url3, {'sb':dqm__maindesc3, 'sw':_ez33[3], 'xbt':_ez37, 'bw':_ez31[3], 'bl': 0 - _ez34[3] + _ez33[3]}
]
];
