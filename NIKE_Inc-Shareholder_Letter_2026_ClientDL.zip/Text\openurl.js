// openurl.js

function Fix2pageURL(urltext) {
		if (urltext.indexOf("-twopage") !== -1) {
			anchortext = '';
			if (urltext.indexOf('#') !== -1) {
				anchortext = urltext.split('#')[1];
				urltext = urltext.split('#')[0];
			}
			
       //if (urltext == 'dicks_sporting_goods-ar2012_0003.htm') { urltext = 'dicks_sporting_goods-ar2012_0002.htm'; }
     	     
		 
			if (anchortext != '') {
				urltext = urltext + '#' + anchortext;
			}		 
		}
		return urltext;
}

function OpenURL(urltext,newwindow) {
	checkdoublepage = true;
	var fullurl = urltext;
	if (urltext.toLowerCase().indexOf('http:') == 0 || urltext.toLowerCase().indexOf('https:') == 0 || urltext.indexOf('.') == 0 || urltext.indexOf('/') == 0) { //don't fix absolute URLs
		checkdoublepage = false;
	}
	
	if (checkdoublepage) {
		var htmreplace = '.htm';
		if (_ez22 != 'default.htm') {
			htmreplace = _ez22.replace("default", "");
		}
		if (urltext.indexOf(htmreplace) == -1) { //Don't replace if it already is -twopage or whatever
		 fullurl = urltext.replace(".htm",htmreplace);
		}
		fullurl = Fix2pageURL(fullurl);
	}
	if (newwindow == 1) { //New Window
		window.open(fullurl, "_blank");
	}
	else { //Existing Window
		window.location.href = fullurl;
	}
}
