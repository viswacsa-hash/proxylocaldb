// EZOnlineDocuments.com JS document settings

var _ez27 = '';
var _ez67 = 4;

var _ez68 = false;
var _ez69 = false;
var _ez92 = 110;
var _ezB35 = 26282;

//if (_ez24 < 900) {
//   _ezB06 = _ezB04;
//} else {
//   _ezB06 = _ezB05;
//}

var _ezCLR=new Array();
_ezCLR[1]="#454545"; 
_ezCLR[2]="#333333"; 
_ezCLR[3]="#e48100"; 
_ezCLR[4]="white"; 
_ezCLR[5]="white"; 
_ezCLR[6]="#e48100"; 
_ezCLR[7]="#d86100"; 
_ezCLR[8]="white"; 
_ezCLR[9]="white"; 
_ezCLR[10]="#333333";
_ezCLR[11]="#1f1f1f";
_ezCLR[12]="white";
_ezCLR[13]="#656565";
_ezCLR[14]="black";
_ezCLR[15]="#aaaaaa";
_ezCLR[16]="white";
_ezCLR[17]="#888888";
_ezCLR[18]="#828282";
_ezCLR[19]="#feba40";
_ezCLR[20]="";
_ezCLR[21]="#717070";
_ezCLR[22]="";
_ezCLR[23]="white";
_ezCLR[24]="#333333";
_ezCLR[25]="#1f1f1f";
_ezCLR[26]="#f47920";
_ezCLR[27]="white";
_ezCLR[28]="white";
_ezCLR[29]="#e48100";
_ezCLR[30]="white";
_ezCLR[31]="#d86100";
_ezCLR[32]="white";
_ezCLR[33]="#e48100";
_ezCLR[34]="#d86100";
_ezCLR[35]="#d86100";
_ezCLR[36]="white";
_ezCLR[37]="white";
_ezCLR[38]="white";
_ezCLR[39]="";
_ezCLR[40]="";




// BC3_START
if (_ez24 < 900) {
	var _ez37 = 35;
	var _ez33 = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	var _ez31 = new Array(300,300,300,300,300,300,300,300,300,300,300,300,300,300);
	var _ez34 = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	var _ez32 = new Array(300,300,300,300,300,300,300,300,300,300,300,300,300,300); 
	var _ez35 = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
} else {
	var _ez37 = 35;
	var _ez33 = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	var _ez31 = new Array(300,300,300,300,300,300,300,300,300,300,300,300,300,300);
	var _ez34 = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	var _ez32 = new Array(300,300,300,300,300,300,300,300,300,300,300,300,300,300); 
	var _ez35 = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
}
var _ez36 = 5; 
var _ez40 = 1;
var _ez41 = 0;
var _ez42 = 1;
var _ez43 = 1;
var _ez44 = 135;
var _ez45 = 180;
var _ez46 = '&nbsp;&nbsp;';
var _ez49 = 127;
var _ez50 = 0; 

var _ez51 = 1; 

var _ez52 = 16;
var _ez53 = '';
var _ez54 = ':';
var _ez55 = 0; 
// _ez30[38] = ""; 
var _ez60 = 0; 
var _ez61 = 15;
var _ez63 = 0; 
// BC3_END
var _ez62 = '{lastnormalurl}';
var _ez64=0; 
var _ez65=1;
var _ez66=0; 
var _ez94 = 0;
var _ez95 = 0;
var _ez96 = 0;
var _ez97 = '';
var _ez98 = ',1,';
var _ezT01 = 0;
var _ezT02 = 0;
var _ezT03 = 1;
var _ezT11 = 0;
var _ezSE01 = 0;
var _ezT04 = 1;
var _ezT13 = 0;
var _ezPI01 = 0;
var _ezPI02 = 1;
var _ezPI03 = 0;
var _ezPI04 = 0;
var _ezPI05 = 1;
var _ezPI06 = 0;
var _ezFH01 = 1;
var _ezFH02 = 801;
var _ezSh01 = 1;
var _ezSh02 = 1;
var _ezSh03 = 1;
var _ezSh04 = 1;
var _ezSh05 = 0;
var _ezSh06 = '';
var _ezB07 = '';
var _ezB08 = '';
var _ezB09 = '';
var _ezB10 = '';
var _ezB11 = '';
var _ezB31 = 0;
var _ezB36 = 0;
var _ezB37 = ',1,';
var _ezB46 = 0;
var _ezB47 = 0;
var _ezB48 = 0;
var _ezB49 = 0;
var _ezB50 = 0;
var _ezB51 = 0;
var _ezB52 = 960;
var _ezB53 = 1200;
var _ezB54 = 0;


if (_ezB38 == 1) { 
	var _ezB39 = '<table cellpadding=0 cellspacing=0 width="100%" class="menuhelp"><tr><td width="12"><img src="../images/menuhelper-left.gif" width="12" height="18"></td><td align="right" class="menuhelp">[MENUHELPER]</td><td width="35" class="menuhelp"><img src="../images/menuhelper-arrowup.gif" width="17" height="18"></td><td width="12" align="right"><img src="../images/menuhelper-right.gif" width="12" height="18"></td></tr></table>';
} else {
	var _ezB39 = '<table cellpadding=0 cellspacing=0 width="100%" class="menuhelp"><tr><td width="12"><img src="../images/menuhelper-left.gif" width="12" height="18"></td><td align="center" class="menuhelp"  height="18"><table  cellpadding=0 cellspacing=0  class="menuhelp"><tr><td width="35" class="menuhelp" align="right"><img src="../images/menuhelper-arrowup.gif" width="17" height="18"></td><td class="menuhelp">[MENUHELPER]</td></tr></table></td><td width="12" align="right"><img src="../images/menuhelper-right.gif" width="12" height="18"></td></tr></table>';
}

//var _ezB43 = '<table cellpadding="2" cellspacing="0" border="0" align="center" valign="center" width="[MENUTABWIDTH]" height="[MENUTABHEIGHT]" [MENUBORDERSTYLE]><tr><td align="center" valign="center" style="padding: 2px; ' + 'font-family: Verdana; font-size: 11px; color:[MENUTEXTCOLOR]" [MENUBGTAG]>[MENUTEXT]</td></tr></table>';

//var _ezB44 = '<table cellpadding="2" cellspacing="0" border="0" bgcolor="[MENUBGCOLOR]" height="20" width="[MENUTABWIDTH]" [MENUBORDERSTYLE]><tr><td align="left" valign="top" style="padding: 2px; font-family: Verdana; font-size: 11px; color:[MENUTEXTCOLOR]">[MENUTEXT]</td></tr></table>';

//var _ezB45 = '<table cellpadding="2" cellspacing="0" border="0" bgcolor="[MENUBGCOLOR]" height="20" width="[MENUTABWIDTH]" [MENUBORDERSTYLE]><tr><td align="left" valign="top" style="padding: 2px; font-family: Verdana; font-size: 11px; color:[MENUTEXTCOLOR]">[MENUTEXT]</td></tr></table>';

var _ezB43 = '<table cellpadding="2" cellspacing="0" border="0" width="[MENUTABWIDTH]" height="[MENUTABHEIGHT]" [MENUSTYLE]><tr><td [MENUINNERSTYLE] [MENUBGTAG]>[MENUTEXT]</td></tr></table>';
var _ezB44 = '<table cellpadding=0 cellspacing="0" border="0" height="20" width="[MENUTABWIDTH]" [MENUSTYLE] [MENUBGTAG]><tr><td [MENUINNERSTYLE]>[MENUTEXT]</td></tr></table>';
var _ezB45 = '<table cellpadding=0 cellspacing="0" border="0" height="20" width="[MENUTABWIDTH]" [MENUSTYLE] [MENUBGTAG]><tr><td [MENUINNERSTYLE]>[MENUTEXT]</td></tr></table>';


var _ezB40=new Array();
var _ezB41=new Array();
var _ezB42=new Array();
_ezB40[0]='' 
_ezB41[0]='' 
_ezB42[0]='' 
if (_ezB47 == 1) { 
	_ezB40[0] = '../1024/1024_taball.gif';
	_ezB41[0] = '../1024/1024_taball_over.gif';
	_ezB42[0] = '../1024/1024_taball_active.gif';
}
for (i = 1; i < 15; i++) {
	if (_ezB48 == 1) {
		_ezB40[i]='../1024/1024_tab' + i + '.gif';
		_ezB41[i]='../1024/1024_tab' + i + '_over.gif';
		_ezB42[i]='../1024/1024_tab' + i + '_active.gif';
	} else {
		_ezB40[i]='';
		_ezB41[i]='';
		_ezB42[i]='';
	}
}

// Calculate tab and subtab widths
totalwidth = 0;
unsettabs = 0; 

for (i = 0; i < _ez67; i++) {
	totalwidth = totalwidth + _ez33[i];
	if (_ez33[i] == 0) { unsettabs = unsettabs + 1; }
}
tabadjustment = _ez67 + 1;
if (_ezB38 == 5) { // Tigra menu
	tabadjustment=0; 
}
tabgap = _ezB06 - totalwidth - tabadjustment;
runningtotal = 0;
for (i = 0; i < _ez67; i++) {
	if (_ez33[i] == 0) { _ez33[i] = Math.floor(tabgap / unsettabs); }
	runningtotal = runningtotal + _ez33[i];
	if (i == (_ez67 - 1)) {
		_ez33[i] = _ez33[i] + (_ezB06 - tabadjustment - runningtotal);
	}
	if (_ez31[i] == 0) { _ez31[i] = _ez33[i]; }
	if (_ez31[i] < _ez33[i]) { _ez31[i] = _ez33[i]; }
	if (_ez34[i] == 0) { _ez34[i] = _ez33[i]; }
	if (i == (_ez67 - 1)) {
		if ((_ez31[i] > _ez33[i]) && (_ez34[i] == _ez33[i])) { _ez34[i] = _ez31[i]; }
		_ez31[i] = _ez31[i] - 1;
	}
}

if (_ez67 > 3) {
	if ((_ez31[_ez67-2] > (_ez33[_ez67-2] + _ez33[_ez67-1])) && (_ez34[_ez67-2] == _ez33[_ez67-2])) { 
		_ez34[_ez67-2] = _ez31[_ez67-2] - _ez33[_ez67-1]; 
	}
}

if (_ez67 > 4) {
	if ((_ez31[_ez67-3] > (_ez33[_ez67-3] + _ez33[_ez67-2] + _ez33[_ez67-1])) && (_ez34[_ez67-3] == _ez33[_ez67-3])) { 
		_ez34[_ez67-3] = _ez31[_ez67-3] - _ez33[_ez67-1] - _ez33[_ez67-2]; 
	}
}

if (_ez67 > 5) {
	if ((_ez31[_ez67-4] > (_ez33[_ez67-4] + _ez33[_ez67-3] + _ez33[_ez67-2] + _ez33[_ez67-1])) && (_ez34[_ez67-4] == _ez33[_ez67-4])) { 
		_ez34[_ez67-4] = _ez31[_ez67-4] - _ez33[_ez67-1] - _ez33[_ez67-2] - _ez33[_ez67-3]; 
	}
}

if (_ez67 > 6) {
	if ((_ez31[_ez67-5] > (_ez33[_ez67-5] + _ez33[_ez67-4] + _ez33[_ez67-3] + _ez33[_ez67-2] + _ez33[_ez67-1])) && (_ez34[_ez67-5] == _ez33[_ez67-5])) { 
		_ez34[_ez67-5] = _ez31[_ez67-5] - _ez33[_ez67-4] - _ez33[_ez67-1] - _ez33[_ez67-2] - _ez33[_ez67-3]; 
	}
}

if (_ez67 > 7) {
	if ((_ez31[_ez67-6] > (_ez33[_ez67-6] + _ez33[_ez67-5] + _ez33[_ez67-4] + _ez33[_ez67-3] + _ez33[_ez67-2] + _ez33[_ez67-1])) && (_ez34[_ez67-6] == _ez33[_ez67-6])) { 
		_ez34[_ez67-6] = _ez31[_ez67-6] - _ez33[_ez67-5] - _ez33[_ez67-4] - _ez33[_ez67-1] - _ez33[_ez67-2] - _ez33[_ez67-3]; 
	}
}

var MENU_POS0 = [{
	'hide_delay' : 1,  'expd_delay' : 1,	
	'css' : {
		'table' : 'm0table',
		'inner' : 'm0inner',
		'outer' : ['m0mouto', 'm0movero', 'm0mdowno']
	},
	'table': [0, 0, 0], 
	'wise_pos': 0,
	'pixel':'../images/blank.gif'
}];




// EZOD: G75 - mobile checks
_ez201 = 18;

function _EZF202() {
	//alert(navigator.userAgent.toLowerCase());
	//ez_menubox ez_mobilemenubox
	var mobile = (/iphone|ipad|ipod|android|blackberry|mini|windows\sce|palm|touchpad/i.test(navigator.userAgent.toLowerCase()));  
    if (mobile) {  
      document.getElementById('ez_menubox').style.display = 'none';
      document.getElementById('ez_mobilemenubox').style.display = 'block';
    }  
}
// EZOD: END G75 - mobile checks

_EZF15();

