<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<!-- EZOnlineDocuments.com: EnhancedResponsive Ver.Jan2017 --> 

<title>NIKE, Inc. 2026 Annual Report</title>
<meta http-equiv="X-UA-Compatible" content="IE=EDGE" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, shrink-to-fit=no, viewport-fit=contain" />

<link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>

<style>
@font-face {
    font-family: 'Helvetica Neue';
    src: url('../images/helveticaneue.eot');
    src: url('../images/helveticaneue.eot?#iefix') format('embedded-opentype'),
         url('../images/helveticaneue.woff') format('woff'),
         url('../images/helveticaneue.ttf') format('truetype'),
         url('../images/helveticaneue.svg#helveticaneue') format('svg');
    font-weight: normal;
    font-style: normal;

}
</style>
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">

<link rel="stylesheet" href="../Text/font-awesome.min.css" type="text/css" />
<link rel="stylesheet" href="../Text/styles.css" type="text/css" />
<link rel="stylesheet" href="../Text/skeleton1440.css" type="text/css" />
<link rel="stylesheet" href="../Text/mc_styles_switcher.css" type="text/css" />


<style type="text/css">
/* #ez_contentbox {	background: url(../images/body-bg960.jpg) top center no-repeat; } */
#ez_logobox {	height: 110px; }
</style>


<!--[if lt IE 9]>
<link rel="stylesheet" href="../Text/mc_styles_960.css" type="text/css" />
<link rel="stylesheet" href="../Text/ie8_specific_styles.css" type="text/css" />
<![endif]-->

<!--[START-LJ]-->
<script type='text/javascript' src='../Text/quickmenu.js'></script>
<!--[END-LJ]-->

<script type="text/javascript" src='../Text/css_browser_selector.js'></script>
<script type="text/javascript" src="../Text/browser-detection.js"></script>

<!--[if lt IE 7]>
<style type="text/css">	
	A.box   { border : thin solid #f47920;}
	A.box:visited { border : thin solid  #f47920;}
	A.box:hover{border : thin solid  #d86100;}
</style>
<![endif]-->

<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon" />


<script type="text/javascript">
//<![CDATA[
var _ez16 = 2; 
var _ez09 = 1;
var _ez20 = '{prevurl}';
var _ez21 = 'financials.htm';
var _ez22 = 'default.htm';
var _ez23 = 'financials.htm';
var _ezIsTilesPage = '1';
var _ez24 = 777;
var _ezB04 = 776 + 1;
var _ezB05 = 1000 + 1;
var _ezB06 = 960;
var _ez72 = 'In Linear Only';
var _ez47 = '{prevnormalurl}';
var _ezB03 = 'default.htm';
var _ezB38 = 2;
var isSinglePage = '0';
var isPaired = 'false';
var _ez73 = 'contents.htm';
var _ez80 = 'print.htm';
var _ez01 = 'results.htm';
var _ez81 = 'thumbnails.htm';
var _ez82 = 'help.htm';
var _ezB01 = '';
var _ezB02 = '';

//]]>
</script>
<script type="text/javascript" src="../Text/localization-english.js"></script>
<script type='text/javascript' src='../Text/jquery-3.5.1.min.js'></script>
<script type='text/javascript' src='../Text/jquery-migrate-1.4.1.min.js'></script>
<script type='text/javascript' src='../Text/jquery.cookie.js'></script>
<script type="text/javascript" src="../Text/jse_form.js"></script>
<script type="text/javascript" src="../Text/jse_fixedheader.js"></script>
<script type="text/javascript" src="../Text/settings.js"></script>
<script type="text/javascript" src="../Text/openurl.js"></script>

<script type="text/javascript" src="../Text/ddsmoothmenu.js"></script>
<script type="text/javascript" src="../Text/combinedjs1.js"></script>


<!--[if gt IE 8]><!-->
<script type="text/javascript" src="../Text/combinedjs_noie8_2.js"></script>
<!--<![endif]-->
<script type="text/javascript">
//<![CDATA[
_EZF04('','financials-thumbview.htm');
//]]>
</script>
<script type='text/javascript' src='../Text/responsivefunctions.js'></script>

<link rel="stylesheet" href="../responsive/responsive.css" type="text/css" />
</head>



<body>
<!--[if lt IE 9]> 
<style>
.ez_oldbrowserwarningcss { display: block !important; padding: 150px 150px 150px 150px; background-color: #333333; color: white; font-size:20px;  }
</style>
<![endif]-->

<div class="ez_oldbrowserwarningcss" style="display:none;">
<b>Warning</b>: your browser is no longer supported.<br/><ul><li><a href="http://www.ezonlinedocuments.com/browsers" target="_blank">CLICK HERE</a> to review the supported browser list.</li><li><a href="../images/NIKE-Shareholder_Letter_2026.pdf" target="_blank">CLICK HERE</a> to download a PDF version of this report to read and/or print.</li></ul>
</div>






<div class="ezwrapper"><div class="ez_bigbgdiv ez_bigbgoverride_default.asp">
<div class="display768orsmaller" id="ezmobilenavbox-outer">
<div id="ezmobilenavbox-inner"><!-- MOBILE DOC SWITCHER -->
 <div id="mobile-docswitchtabs">&nbsp;&nbsp;<font color="F47920"><b>CEO Letter to Shareholders</b></font>&nbsp;|&nbsp;&nbsp;<a href="https://materials.proxyvote.com/NIKE/NPS26" class="ez_navbartop">Proxy Statement</a>&nbsp;|&nbsp;&nbsp;<a href="https://materials.proxyvote.com/NIKE/FORM10K26" class="ez_navbartop">10-K</a></div>
<div class="container clearfix">
<div id="ezmobilelogoouterdiv">
<div id="ezmobilelogoinnerdiv">
	<a href="default.htm" id="mobilelogolink"><img src="../images/logo-mobile.png" /></a>
</div>
</div>
<div style="" id="ezmobilebuttonandmenudiv">
          <nav id="menu" class="navigation" role="navigation">
		  <a href="#" class="tplnavsmallbutton" id="btnMobileMenuOnResponsive">
		  <div id="mobilemenuclosed">
		  <div class="nav-MenuMobile"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Menu" title="Menu" /></div><div class="navMobileText">Menu</div>
		  </div>
		  <div id="mobilemenuopen">
		  <div class="nav-MenuCloseMobile"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Close" title="Close" /></div><div class="navMobileText">Close</div>
		  </div>
		  </a>
<!-- mobile menus -->
<ul id="nav"><!-- MULTI DOC MENU IF ANY --><!-- GENERIC 102 - PRE MENU ITEMS IN HAMBURGER MENU, IF ANY -->
<li><a class="DDSMEZODactiveLevel1 DDSMEZODLevel1Tab1" href="default.htm" >CEO Letter to Shareholders</a>
</li>
<li><a class=" DDSMEZODLevel1Tab2" href="financials.htm" >Select Financials</a>
</li>
<li><a class=" DDSMEZODLevel1Tab3" href="https://materials.proxyvote.com/NIKE/NPS26" >Proxy Statement</a>
</li>
<li><a class=" DDSMEZODLevel1Tab4" href="https://materials.proxyvote.com/NIKE/FORM10K26" >10-K</a>
</li>
<!-- HELP MENU -->
<li id="helpandfeatures"><a href="help.htm" aria-haspopup="true">Help &amp; Features</a><ul>
<!--ONEPDFSTART--> 
<li class="hide0 hide_ezod-kitdownloadsprintoff_"><a href="../images/NIKE-Shareholder_Letter_2026.pdf" target="_blank"><div class="nav-OnePDF ddmobileicondiv"></div><div class="ddmobileicontextdiv">Download PDF</div><div class="clearfix"></div></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a href="print.htm?source=downloadbutton"><div class="nav-Download ddmobileicondiv"></div><div class="ddmobileicontextdiv">Downloads</div><div class="clearfix"></div></a></li>
<!--ONEPDFEND-->

<li class="hide0"><a href="https://www.nike.com" target="_blank"><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Company Home</div><div class="clearfix"></div></a></li>
<li class="show1"><div class="nav-Help ddmobileicondiv"></div><a href="#" aria-haspopup="true">Share</a><ul>
  <script type = "text/javascript" >

  if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') { 
  	_EZFMM51(1,'NIKE, Inc. 2026 Annual Report','','NIKE, Inc. 2026 Annual Report'); 
  } else { 
  	_EZFMM51(1,'{hosting_BtnCustom4stripped}','','{hosting_BtnCustom4stripped}'); 
  } 
</script>
</ul></li>
<li class="hide0"><a href="print.htm?p1url=nike-shareholder_letter_2026_0001.pdf&amp;p1thu=thumb_nike-shareholder_letter_2026_0001.gif&amp;p2url=&amp;p2thu="><div class="nav-Print ddmobileicondiv"></div><div class="ddmobileicontextdiv">Print</div><div class="clearfix"></div></a></li>
<li class="show1"><a href="contents.htm"><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Clickable Index</div><div class="clearfix"></div></a></li>
<li class="show1"><a href="thumbnails.htm"><div class="nav-Thumbs ddmobileicondiv"></div><div class="ddmobileicontextdiv">Thumbnails</div><div class="clearfix"></div></a></li>
<li class="show0"><a href="accessibility.htm">Accessibility Features</a></li>
<li class="hide0"><a href="help.htm"><div class="nav-Help ddmobileicondiv"></div><div class="ddmobileicontextdiv">Help</div><div class="clearfix"></div></a></li>
<!-- <li class="show0 show0"><a href="default.htm"><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Single Page View</div><div class="clearfix"></div></a></li> -->
<!-- <li class="show0 show0"><a href=""><div class="nav-Index ddmobileicondiv"></div><div class="ddmobileicontextdiv">Double Page View</div><div class="clearfix"></div></a></li> -->
<!-- <li id="tilesmobilenavmenu" class="show0"><a href="javascript:_ezFH1008('HTML1','tiles.htm');"><div class="nav-Tiles ddmobileicondiv"></div><div class="ddmobileicontextdiv">Home Page</div><div class="clearfix"></div></a></li> -->
<!-- <li class="show1"><div class="nav-Help ddmobileicondiv"></div><a href="results.htm">Search</a></li> -->
</ul></li></ul>

<!-- mobile menus -->

         </nav>
	<div id="ezmobilebuttonstoprightdiv" class="display768orsmaller" style="float:right; margin-right:5px;">
<ul class="ulMobileItems" style="list-style-type: none;">
<li id="btnMobileMenuOffResponsive" class="libtnMenuMobileDisabled" style="display:none;"><a href="#" class="nav-MenuMobileDisabled" id="nav-MenuMobileDisabled"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Menu" title="Menu" /></a><div class="navMobileText">Menu</div></li>
<li class="libtnZoominMobile" id="smalldoubletaptext" style="display:none;"><div style="padding-left:8px;"><a href="javascript:showBigZoom();" class="nav-ZoomInMobileBig"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /></a></div><div class="navMobileText">Zoom In</div></li>
<li class="libtnZoomOutMobile" id="largedoubletaptext" style="display:none;"><div style="padding-left:12px;"><a href="javascript:hideBigZoom();" class="nav-ZoomOutMobileBig"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom Out" title="Zoom Out" /></a></div><div class="navMobileText">Zoom Out</div></li>
<li id="btnZoomOffResponsive" class="libtnZoomDisabledMobile"><div style="padding-left:8px;"><a href="#" class="nav-ZoomInMobileBigDisabled"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /></a></div><div class="navMobileText">Zoom In</div></li>

<li id="btnSearchOnResponsive" class="libtnSearchMobile show1 show1" style="margin-right:8px;"><div style="padding-left:6px;"><a href="results.htm" class="nav-SearchMobileBig"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Search" title="Search" /></a></div><div class="navMobileText">Search</div></li>
<li id="btnSearchOnCurPageResponsive" class="libtnSearchMobile show1 hide1" style="margin-right:8px;"><div style="padding-left:6px;"><a href="results.htm" class="nav-SearchMobileBigOn"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Search" title="Search" /></a></div><div class="navMobileText">Search</div></li>
<li id="btnSearchOffResponsive" class="libtnSearchMobileDisabled"  style="display:none;"><div style="padding-left:6px;"><a href="#" class="nav-SearchMobileBigDisabled"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Search" title="Search" /></a></div><div class="navMobileText">Search</div></li>

<li class="show1" id="nav-TilesIDMobile" style="display:none; margin-right:9px;"><div style="padding-left:4px;"><a href="javascript:_ezFH1008('HTML1','tiles.htm');" class="nav-TilesMobile" id="nav-TilesIDA"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li class="hide1" id="nav-TilesIDOnMobile" style="margin-right:9px;"><div style="padding-left:4px;"><a href="default.htm" class="nav-TilesMobileOn" id="nav-TilesIDAOn"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li id="btnTilesOffResponsive" class="libtnTilesMobileDisabled" style="display:none; margin-right:9px;"><div style="padding-left:4px;"><a class="nav-TilesMobileDisabled" id="nav-TilesMobileDisabledA"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li class="hide0 show0" id="nav-HomeNoTilesMobileID" style="margin-right:9px;"><div style="padding-left:4px;"><a href="default.htm" class="nav-TilesMobile" id="nav-HomeNoTilesmobileIDA"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>
<li class="hide0 hide0" id="nav-HomeNoTilesMobileDefaultPageID" style="margin-right:9px;"><div style="padding-left:4px;"><a href="default.htm" class="nav-TilesMobileOn" id="nav-HomeNoTilesMobileDefaultPageID"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /></a></div><div class="navMobileText">Home</div></li>

</ul>
</div>


</div>
<div style="display:none;" id="ezzoomlargescreenbuttons">
<div class="" style="float:right; margin-right:5px;">
<ul class="ulMobileItems" style="list-style-type: none;">
<li class="largescreenzoomminus" id="largescreenzoomminus"><div style="padding-left:14px;"><a href="javascript:hideBigZoomDesktop('0','false');" class="nav-ZoomMinus"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom Out" title="Zoom Out" /></a></div><div class="navMobileText">Zoom Out</div></li>
</ul>
</div>
</div>


<div class="clearfix"></div>

</div>
</div>
</div>



<div id="ez_header" class="fullwidth display960orlarger">
<!-- DESKTOP DOC SWITCHER -->
<!-- NIKE TOGGLE BAR START  -->
<div id="nike_navtop">&nbsp;
<font color="#F47920"><b>CEO Letter to Shareholders</b>&nbsp;</font>
|&nbsp; <a href="https://materials.proxyvote.com/NIKE/NPS26" class="ez_navbartop">Proxy Statement</a> 
|&nbsp; <a href="https://materials.proxyvote.com/NIKE/FORM10K26" class="ez_navbartop">10-K</a>
</div>
<!-- NIKE TOGGLE BAR END  -->
	<div id="ez_rightbgbox"></div>
<div id="ez_logobox"></div>
<div id="ez_logo"><a href="default.htm"><img src="../images/logo.png" border="0" alt="" /></a></div>
<div id="ez_titlebox">
<div id="ez_doctitle">2026 Annual Report</div>
<div id="ez_subdoctitle"></div>
</div>

</div>


<div id="eznavbox-outer" class="eznavbox-outer_ezod-kitoff_ display960orlarger"><div id="eznavbox-inner" class="eznavbox-inner_ezod-kitoff_">
<div id="ezkitlinkitems" class="container show_ezod-kitoff_ show{showdocswitchertabsflag}"><table width="100%" border="0" cellspacing="1" cellpadding="0" class="sub1">
		 		<tr class="framenav">
			<td id="doc0tab" class="framehdrbg{hosting_isCurrentDoc} show{hosting_exists}" align="center"><a id="doc0link" href="{hosting_rooturl}HTML1/default.htm" class="framehdrfont{hosting_isCurrentDoc}">{hosting_shortdoctitlestripped}</a></td>
			<td id="doc1tab" class="framehdrbg{doc1_isCurrentDoc} show{doc1_exists}" align="center"><a id="doc1link" href="{doc1_rooturl}HTML1/default.htm" class="framehdrfont{doc1_isCurrentDoc}">{doc1_shortdoctitlestripped}</a></td>
			<td id="doc2tab" class="framehdrbg{doc2_isCurrentDoc} show{doc2_exists}" align="center"><a id="doc2link" href="{doc2_rooturl}HTML1/default.htm" class="framehdrfont{doc2_isCurrentDoc}">{doc2_shortdoctitlestripped}</a></td>
			<td id="doc3tab" class="framehdrbg{doc3_isCurrentDoc} show{doc3_exists}" align="center"><a id="doc3link" href="{doc3_rooturl}HTML1/default.htm" class="framehdrfont{doc3_isCurrentDoc}">{doc3_shortdoctitlestripped}</a></td>
			<td id="doc4tab" class="framehdrbg{doc4_isCurrentDoc} show{doc4_exists}" align="center"><a id="doc4link" href="{doc4_rooturl}HTML1/default.htm" class="framehdrfont{doc4_isCurrentDoc}">{doc4_shortdoctitlestripped}</a></td>
			<td id="doc5tab" class="framehdrbg{doc5_isCurrentDoc} show{doc5_exists}" align="center"><a id="doc5link" href="{doc5_rooturl}HTML1/default.htm" class="framehdrfont{doc5_isCurrentDoc}">{doc5_shortdoctitlestripped}</a></td>
			<td id="doc6tab" class="framehdrbg{doc6_isCurrentDoc} show{doc6_exists}" align="center"><a id="doc6link" href="{doc6_rooturl}HTML1/default.htm" class="framehdrfont{doc6_isCurrentDoc}">{doc6_shortdoctitlestripped}</a></td>
			<td id="doc7tab" class="framehdrbg{doc7_isCurrentDoc} show{doc7_exists}" align="center"><a id="doc7link" href="{doc7_rooturl}HTML1/default.htm" class="framehdrfont{doc7_isCurrentDoc}">{doc7_shortdoctitlestripped}</a></td>
			<td id="doc8tab" class="framehdrbg{doc8_isCurrentDoc} show{doc8_exists}" align="center"><a id="doc8link" href="{doc8_rooturl}HTML1/default.htm" class="framehdrfont{doc8_isCurrentDoc}">{doc8_shortdoctitlestripped}</a></td>
			<td id="doc9tab" class="framehdrbg{doc9_isCurrentDoc} show{doc9_exists}" align="center"><a id="doc9link" href="{doc9_rooturl}HTML1/default.htm" class="framehdrfont{doc9_isCurrentDoc}">{doc9_shortdoctitlestripped}</a></td>
			<td id="doc10tab" class="framehdrbg{doc10_isCurrentDoc} show{doc10_exists}" align="center"><a id="doc10link" href="{doc10_rooturl}HTML1/default.htm" class="framehdrfont{doc10_isCurrentDoc}">{doc10_shortdoctitlestripped}</a></td>
			<td id="doc11tab" class="framehdrbg{doc11_isCurrentDoc} show{doc11_exists}" align="center"><a id="doc11link" href="{doc11_rooturl}HTML1/default.htm" class="framehdrfont{doc11_isCurrentDoc}">{doc11_shortdoctitlestripped}</a></td>
			<td id="doc12tab" class="framehdrbg{doc12_isCurrentDoc} show{doc12_exists}" align="center"><a id="doc12link" href="{doc12_rooturl}HTML1/default.htm" class="framehdrfont{doc12_isCurrentDoc}">{doc12_shortdoctitlestripped}</a></td>
			<td id="doc13tab" class="framehdrbg{doc13_isCurrentDoc} show{doc13_exists}" align="center"><a id="doc13link" href="{doc13_rooturl}HTML1/default.htm" class="framehdrfont{doc13_isCurrentDoc}">{doc13_shortdoctitlestripped}</a></td>
			<td id="doc14tab" class="framehdrbg{doc14_isCurrentDoc} show{doc14_exists}" align="center"><a id="doc14link" href="{doc14_rooturl}HTML1/default.htm" class="framehdrfont{doc14_isCurrentDoc}">{doc14_shortdoctitlestripped}</a></td>
			<td id="doc15tab" class="framehdrbg{doc15_isCurrentDoc} show{doc15_exists}" align="center"><a id="doc15link" href="{doc15_rooturl}HTML1/default.htm" class="framehdrfont{doc15_isCurrentDoc}">{doc15_shortdoctitlestripped}</a></td>
		</tr>
		</table></div>	
<div id="ez_navbox">
	<div id="ez_commandmenubox"><div id="ez_row1box" class="container"><div id="ez_row1paddingdiv">
		
<span class="ezod_commandicons"> 
<ul>

<li class="show1" id="nav-TilesID" style="display:none;"><a href="javascript:_ezFH1008('HTML1','tiles.htm');" class="nav-Tiles" id="nav-TilesIDA"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<li class="hide1" id="nav-TilesIDOn"><a href="default.htm" class="nav-TilesOn" id="nav-TilesIDAOn"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<li class="hide0 show0" id="nav-HomeNoTilesID"><a href="default.htm" class="nav-Tiles" id="nav-HomeIDA"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<li class="hide0 hide0" id="nav-HomeNoTilesOnID"><a href="default.htm" class="nav-TilesOn" id="nav-HomeOnIDA"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Home" title="Home" /><span>Home</span></a></li>
<!--ONEPDFSTART--> 
<!--
<li class="hide0 hide_ezod-kitdownloadsprintoff_"><a href="../images/NIKE-Shareholder_Letter_2026.pdf" class="hide0 nav-OnePDF" target="_blank"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Download PDF" title="Download PDF" /><span>Download PDF</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide1 nav-DownloadDisabled" id="nav-DownloadIsCurrentPageDisabled-Top"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide1 show1 nav-DownloadOn" id="nav-DownloadIsCurrentPageOn-Top"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a href="print.htm?source=downloadbutton" class="show1 nav-Download"  id="nav-DownloadNormal-Top"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Downloads" title="Downloads" /><span>Downloads</span></a></li>
-->
<!--ONEPDFEND-->

<li class="hide0"><script type="text/javascript">
//<![CDATA[
if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF11Sprite(1,'NIKE, Inc. 2026 Annual Report','');
} else {
	_EZF11Sprite(1,'{hosting_BtnCustom4stripped}','');
}
//]]>
</script>
<script type="text/javascript">
//<![CDATA[ 
if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF51(0,'NIKE, Inc. 2026 Annual Report','','NIKE, Inc. 2026 Annual Report');
} else {
	_EZF51(0,'{hosting_BtnCustom4stripped}','','{hosting_BtnCustom4stripped}');
}
//]]>
</script>

</li>
<li class="hide0"><a class="hide1 nav-PrintOn" id="nav-PrintIsCurrentPageOn-Top"><span>Print</span></a></li>
<li class="hide0"><a class="hide1 show1 nav-PrintDisabled" id="nav-PrintIsCurrentPageDisabled-Top"><span>Print</span></a></li>
<li class="hide0"><a href="print.htm?p1url=nike-shareholder_letter_2026_0001.pdf&amp;p1thu=thumb_nike-shareholder_letter_2026_0001.gif&amp;p2url=&amp;p2thu=" class="show1 nav-Print" id="nav-PrintNormal-Top"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Print" title="Print" /><span>Print</span></a></li>
<li class="show1"><a class="hide1 nav-IndexOn"><span>Clickable Index</span></a></li>
<li class="show1"><a href="contents.htm" class="show1 nav-Index"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Clickable Index" title="Clickable Index" /><span>Clickable Index</span></a></li>
<li class="show1"><a class="hide1 nav-ThumbsOn"><span>Thumbnails</span></a></li>
<li class="show1"><a href="thumbnails.htm" class="show1 nav-Thumbs"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Thumbnails" title="Thumbnails" /><span>Thumbnails</span></a></li>
<!--
<li class="hide0 show0 display1200orsmaller largescreenzoomplus" id="largescreenzoomplus" style="display:none;"><a href="javascript:showBigZoomDesktop('0','false');" class="nav-ZoomPlus"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 hide0 largescreenzoomplus" id="largescreenzoomplustwopage" style="display:none;"><a href="javascript:showBigZoomDesktop('0','false');" class="nav-ZoomPlus"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 largescreenzoomplusdisabled display1200orsmaller" id="largescreenzoomplusdisabled" style=""><a href="#" class="nav-ZoomPlusDisabled"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
-->


<li class="hide0"><a class="hide1 nav-HelpOn"><span>Help</span></a></li>
<li class="hide0"><a href="help.htm" class="show1 nav-Help"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Help" title="Help" /><span>Help</span></a></li>
</ul>
<script type="text/javascript">
//<![CDATA[
_EZF39Div();
if (_ez60 == 0) {
	_EZF01();
	document.write('<div class="searchdiv"><form class="zzez_searchbox ez_searchboxtopform" id="jse_Form1" name="jse_Form1" method="get" action="' + _ez01 + '" onsubmit="return _EZF02(\'d1\');"><ul>');
	_EZF13_Sprite(1);
	document.write('</ul><div class="clearfix" style="clear:both;"></div></form></div>');
}
//]]>
</script>
	</span>
<span class="ezod_pin" style="display:none;visibility:hidden;">
	<div class="ez_pindiv show1 hide0">
<ul class="ulPinItems">
<li class="libtnPinOn"><a onclick="_ezFH1003(false);" class="nav-PinOn"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Unpin Menu Bar" title="Unpin Menu Bar" /><span>Unpin Menu Bar</span></a></li>
<li class="libtnPinOff"><a onclick="_ezFH1003(true);" class="nav-Pin"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Pin Menu Bar" title="Pin Menu Bar" /><span>Pin Menu Bar</span></a></li>
</ul>
</div>
</span>
<span class="ezod_linearnavigation" id="LinearNavSpanTop">
<div class="ez_pageprevnexttop">
<ul>
<li class="hide0 show0 show1"><a href="javascript:_ezFH1008('HTML1','tiles.htm');" class="nav-PrevPage"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="hide0 hide0"><a class="hide0 nav-PrevPageDisabled"><span>Go to previous page</span></a></li>
<li class="hide0 hide1"><a class="hide0 nav-PrevPageDisabled"><span>Go to previous page</span></a></li>
<li class="show0"><a href="{prevurl}" class="show0 nav-PrevPage"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="show1"><a href="financials.htm" class="show1 nav-NextPage"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
<li class="hide1 show1"><a class="hide1 nav-NextPageDisabled"><span>Go to next page</span></a></li>
<li class="hide1 hide1"><a href="default.htm" class="nav-NextPage"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
</ul>
</div>

<script type="text/javascript" src="../Text/jse_pdfpagenumbering.js"></script>
<script type="text/javascript">
//<![CDATA[
write_dropdownmenudiv('1');
//]]>
</script>

<!--PAGENOTZEROSTART-->
<noscript>
		<div class="ez_pagenumtext">Page&nbsp;1&nbsp;of&nbsp;2</div>
</noscript>
<script type="text/javascript">
//<![CDATA[
_EZF24Div(1,'Page','of','1',2,'','1','#333333');
//]]>
</script>
<!--PAGENOTZEROEND-->
</span>

</div></div></div>
<div id="ez_menuboxouter">
<div id="ez_menubox" class="container"><ul id="qm0" class="qmmc">
<li><a class="qmparent EZODactiveLevel1 EZODLevel1Tab1" href="default.htm" ><span>CEO Letter to Shareholders</span></a>
</li>
<li><a class="qmparent EZODLevel1Tab2" href="financials.htm" ><span>Select Financials</span></a>
</li>
<li><a class=" EZODLevel1Tab3" href="https://materials.proxyvote.com/NIKE/NPS26" ><span>Proxy Statement</span></a>
</li>
<li><a class=" EZODLevel1Tab4" href="https://materials.proxyvote.com/NIKE/FORM10K26" ><span>10-&#8203;K</span></a>
</li>
<li class="qmclear">&nbsp;</li></ul>

<script type="text/javascript">qm_create(0,false,0,500,false,false,false,false,false);</script>
</div><div id="ez_mobilemenubox" class="container" style="display:none;"><ul id="qm1" class="qmmc">
<li><a class="qmparent EZODactiveLevel1 EZODLevel1Tab1" href="default.htm" ><span>CEO Letter to Shareholders</span></a>
</li>
<li><a class="qmparent EZODLevel1Tab2" href="financials.htm" ><span>Select Financials</span></a>
</li>
<li><a class=" EZODLevel1Tab3" href="https://materials.proxyvote.com/NIKE/NPS26" ><span>Proxy Statement</span></a>
</li>
<li><a class=" EZODLevel1Tab4" href="https://materials.proxyvote.com/NIKE/FORM10K26" ><span>10-&#8203;K</span></a>
</li>
<li class="qmclear">&nbsp;</li></ul>

<script type="text/javascript">qm_create(1,false,0,500,false,false,false,false,false);</script>
</div>
</div>


<script type="text/javascript">
//<![CDATA[
_EZF202(); 
//]]>
</script>
</div>
</div>
</div>

<div id="ez_contentbox" class="ez_contentboxHTML1"><table id="ez_containerbox" cellpadding="0" cellspacing="0"><tr><td>
	
<div id="ez_documentbox" class="visibleitem fullwidth"><div id="ContentDiv" class="show1">
<script type="text/javascript">
//<![CDATA[
_EZF45();
//]]>
</script>
<div class="clearfix"></div>
<div class="hide0 show0 ez_prevcontinuediv" id="ez_dblpagebuttondivtop" style="display:none;">
<div style="text-align:center; height:23px;" class="ez_LargeBtnContinueDiv">
<span class="show0">
<span class="show0"><a href="default.htm" class="nav-SinglePageView" id="nav-SinglePageViewA"><img src="../images/blank.gif" class="blankgifspacerpageview" alt="Single Page View" title="Single Page View" /><span>Single Page View</span></a></span>
<span class="show0"><a href="" class="nav-DoublePageView" id="nav-DoublePageViewA"><img src="../images/blank.gif" class="blankgifspacerpageview" alt="Double Page View" title="Double Page View" /><span>Double Page View</span></a></span>
</span>
</div>
</div>

<script>
if ('false' == 'true' && '0' == '1') {
	$('#ez_dblpagebuttondivtop').show();
}
</script>

<!-- EZOD_CONTENT_START -->

<style>
@font-face{font-family:'futura-cond-exbold'; src:url("../nikefiles/futura-condensedextrabold-web.eot")}
@font-face{font-family:'futura-cond-exbold'; src:url("../nikefiles/futura-condensedextrabold-web.woff") format("woff"),url("../nikefiles/futura-condensedextrabold-web.ttf") format("truetype"); font-weight:normal; font-style:normal}

@font-face {
    font-family: 'Helvetica Neue LT Std';
    src: url('../nikefiles/HelveticaNeueLTStd-Lt.woff2') format('woff2'),
        url('../nikefiles/HelveticaNeueLTStd-Lt.woff') format('woff'),
        url('../nikefiles/HelveticaNeueLTStd-Lt.ttf') format('truetype');
    font-weight: 400;
    font-style: normal;
    font-display: swap;
}

@font-face {
    font-family: 'Helvetica Neue LT Std';
    src: url('../nikefiles/HelveticaNeueLTStd-Md.woff2') format('woff2'),
        url('../nikefiles/HelveticaNeueLTStd-Md.woff') format('woff'),
        url('../nikefiles/HelveticaNeueLTStd-Md.ttf') format('truetype');
    font-weight: 500;
    font-style: normal;
    font-display: swap;
}

p.date {     color: #2d2d2d;
    font-size: 14px;
    font-family: 'Helvetica Neue LT Std';
    text-transform: uppercase;
    -webkit-font-smoothing: antialiased; }
h3, .ceocapt  {     color: #2d2d2d;
    font-size: 18px;
    font-family: 'Helvetica Neue LT Std';
    letter-spacing: 0.5px;
    line-height: 18px;
    text-transform: none;
	
    -webkit-font-smoothing: antialiased; font-weight: 500; }

p.greeting {     /* color: #E57200; */
    font-size: 18px;
    height: 15px;
	font-weight: bold;
    font-family: 'Helvetica Neue LT Std';
    text-transform: uppercase;
    letter-spacing: 0.5px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
	margin-bottom:32px !important;
}


	
li {

}	
ul.orangeul {
	margin-top: 0px;
	margin-bottom: 16px;
	color:#f57523;
}

ul.orangeul span {
	color: #242021;
}

ol.orangeul {
	margin-top: 0px;
	margin-bottom: 16px;
	color:#f57523;
	font-weight: 500;
	padding-left: 0px;           /* Remove default padding */
	list-style: none;          /* Remove default list styling */
	counter-reset: item;       /* Initialize counter */
}

ol.orangeul li {
  counter-increment: item;   /* Increment counter for each li */
  position: relative;        /* Positioning context */
  margin-bottom: 0.5em;
  padding-left: 2.5em;       /* Indent the text */
}

ol.orangeul li::before {
  content: counter(item);  /* Show the number with a dot */
  position: absolute;
  left: 0;                     /* Align number flush left */
  width: 2em;                  /* Reserve space for number */
  text-align: left;
}


ol.orangeul span {
	color: #242021;
	font-weight: normal;
}

a.letter:visited, a.letter:visited {
    color: #F26522;
    text-decoration: none;
}
a.letter:link, a.letter:link {
    color: #F26522;
    text-decoration: none;
    outline: none;
}
a.letter:hover {
	text-decoration: underline;
}
img.letterimage { float: right; padding-left: 20px; padding-bottom: 20px;  }
@media all and (max-width: 700px) {
	img.letterimage { clear: both; float: none; padding: 2px;  margin-left: auto; margin-right: auto; }
}

.letterbox { color: #242021; font-weight: 400; max-width: 1000px; margin-left: auto; margin-right: auto; padding-left: 50px; padding-right: 50px; font-family: 'Helvetica Neue LT Std', sans-serif; font-size:18px; line-height:25px; margin-top:20px; }
.letterbox p { margin-top: 6px; margin-bottom: 16px; }
.letterbox b { font-weight: 500; }
.letterbox p.nobottom { margin-bottom: 0px; }
@media all and (max-width: 500px) {
	.letterbox { padding-left: 5px; padding-right: 5px; }
}

.letterbox sup { vertical-align: baseline;
  position: relative;
  top: -0.4em;
  }


p,h1,h2,h3 { padding-top: 2px; padding-bottom: 2px; }

	
div.sidequote { float:right; width:300px; text-align:left; line-height: 30px; margin: 10px 0px 10px 15px; color: #f5752c; font-size:27px; 
    font-family: 'futura-cond-exbold';
    letter-spacing: 0.5px;
    -webkit-font-smoothing: antialiased; font-weight: 400;
 }
	
div.sideimage { line-height: 0px; }
div.letter-caption { background-color: #EEEEEE; padding:20px 20px 20px 20px; text-align:center; font-size:13px; font-style:italic; border-bottom-right-radius: 15px; border-bottom-left-radius: 15px; margin-top: 0px; line-height: normal; }

@media all and (max-width: 767px) {
div.sidequote { width:95%; margin-left:auto; margin-right:auto; margin-top:15px; margin-bottom:15px; float:none; }
.hidemobile { display: none; }
}

img { max-width:100%; }
div.letterlogo { text-align:center; }
</style>

<div class="letterbox">
<div class="letterlogo"><img src="../nikefiles/letter-logo.png" alt="Nike Logo" /></div>

<p class="greeting">To our shareholders,</p>

<p>When I wrote to you last year, I committed to putting the athlete* back at the center of everything we do to
strengthen Nike for the long term.</p>
<p>In fiscal 2026, we took important steps to do exactly that. We strengthened the foundation of our
business, made significant changes to how we operate, and sharpened our focus on the sports, athletes
and communities we serve. I am encouraged by the progress our team has made and the direction we
are headed.</p>
<p>Through our Win Now actions, we focused on strengthening the fundamentals of Nike across culture,
product, brand storytelling, marketplace and how we serve consumers in our countries and cities. We rebuilt
key capabilities, improved the health of our marketplace and created the conditions for stronger execution.</p>
<p>Win Now is making the comeback possible.</p>
<p>This fiscal year, we refreshed our senior leadership team and flattened our leadership structure to get
closer to the business. We moved approximately 8,000 teammates into vertical sport teams as part of
our new operating model, the Sport Offense, while continuing to simplify and accelerate our supply chain
and technology organizations. These changes are helping us move faster and stay closer to the athlete
and consumer.</p>
<p>As we spend more time with athletes and organize around the sports we serve, we are beginning to see the
impact. Our renewed focus on sport and the value we create for athletes is building energy for our brands
and driving growth in our performance business. We are also accelerating innovation across footwear,
apparel and sport experiences.</p>
<p>Looking at our reported full year results for fiscal 2026, our gross margins slightly expanded while earnings
per share modestly declined, even with significant investment made to reposition and create a healthier
foundation for our business. At the same time, our results are not yet where they need to be.</p>
<p>We are not performing at our full potential, and we are focused on changing that trajectory with urgency and
discipline. Progress has been encouraging, but we know this comeback will not be a straight line. There are
areas where we are gaining traction and others where we still have important work ahead.</p>
<p>What gives me confidence is that we are rebuilding Nike around the things that have always set us apart:
listening to the needs of the world&rsquo;s best athletes and turning those insights into innovation for everyone.
Because as our mission states, if you have a body, you are an athlete*.</p>
<p>That belief has never felt more relevant. Sport creates opportunities and brings people together. It builds
confidence, resilience, health, teamwork and belief. It helps people and communities move forward.</p>
<p>That is why access to sport matters. When more people can play, train, compete and move, athletes,
families, communities and economies all benefit. Creating that access requires partnership and investment.
Nike will continue working with others who share our belief in the power of sport to unlock human potential
and help keep access to play within reach.</p>
<p>Our success extends beyond Nike. It supports athletes, employees, retail partners, suppliers and
communities around the world, and we carry that responsibility with us as we help shape the future of sport.</p>
<p>Looking ahead, our teams are focused on inspiring consumers in modern ways while driving commercial
impact at both global and local sport moments. We will continue to invest in innovation, strengthen how
we show up across digital and physical retail, and create better experiences for consumers and our
marketplace partners.</p>
<p>Across the enterprise, we will operate with greater discipline, improve planning and inventory management,
and build a stronger, more profitable business over time.</p>
<p>Nike was born from a belief in the power of sport, competition and innovation. Those roots remain central
to who we are, even as we serve athletes in every corner of the world. We believe that no company is better
positioned than Nike to serve athletes through the combination of sport, innovation, brand strength and
global scale.</p>
<p>The foundation is stronger than it was a year ago. The direction is clear. Now our opportunity is consistent
execution. We have to prove it season after season, year after year and decade after decade.</p>
<p>We are building Nike the right way for the long term.</p>

<p>With appreciation,</p>
<p><img class="ceosignature" src="../nikefiles/ceo-signature.png" alt="Elliott Hill Signature" /><br/><br/>
<span class="ceocapt">Elliott Hill</span><br/>
President and Chief Executive Officer<br>
NIKE, Inc.</p>

</div>
<!-- EZOD_CONTENT_END -->
<div class="display960orlarger">
<div class="hide0 hide0 ez_prevcontinuediv" id="ez_prevcontinuedivbottom">
<div style="width:20%; float:left; height:23px; text-align:left;" class="continue">
<span class="hide0"><span class="showcont0">&nbsp;&nbsp;&nbsp;<a href="{prevurl}" class="continue">...Previous</a></span></span>
</div>
<div style="width:80%; float:right; height:23px;">
<div style="width:25%; float: right; height:23px; text-align:right;" class="continue">
<span class="hide0"><span class="showcont1"><a href="financials.htm" class="continue">Continue...</a>&nbsp;&nbsp;&nbsp;</span></span>
</div>
</div>
</div>

</div>
</div></div>

</td></tr></table></div>




<script>
$(function(){

	
	if ('1' == '0') {
		$('#mobilefooterpagetotal').hide();
	}

	if ('1' == '0' && '1' != '0' ) {
		$('#ez_mobilefooter').hide();
	} else {

	}
   
});

</script>


<div id="ez_docfooterbox" class="fullwidth display960orlarger"><div id="ez_footerbox" class="fullwidth"><div id="ez_bottomrightbgbox"></div> 
<div id="ez_row4box"><div id="ez_row4paddingdiv">				
<span class="ezod_commandicons"> 
<ul>

<li class="show1" id="nav-TilesIDBottom" style="display:none;"><a href="javascript:_ezFH1008('HTML1','tiles.htm');" class="nav-TilesBottom" id="nav-TilesIDBottomA"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Tiles" title="Tiles" /><span>Tiles</span></a></li>
<li class="hide1" id="nav-TilesIDBottomOn"><a href="default.htm" class="nav-TilesBottomOn" id="nav-TilesIDBottomAOn"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Tiles" title="Tiles" /><span>Tiles</span></a></li>
<!--ONEPDFSTART--> 
<li class="hide0 hide_ezod-kitdownloadsprintoff_"><a href="../images/NIKE-Shareholder_Letter_2026.pdf" class="hide0 nav-OnePDFBottom" target="_blank"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Download PDF" title="Download PDF" /><span>Download PDF</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide1 nav-DownloadBottomDisabled" id="nav-DownloadIsCurrentPageDisabled-Bottom"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a class="hide1 show1 nav-DownloadBottomOn" id="nav-DownloadIsCurrentPageOn-Bottom"><span>Downloads</span></a></li>
<li class="hide0 show_ezod-kitdownloadsprintoff_"><a href="print.htm?source=downloadbutton" class="show1 nav-DownloadBottom" id="nav-DownloadNormal-Bottom"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Downloads" title="Downloads" /><span>Downloads</span></a></li>
<!--ONEPDFEND-->

<li class="hide0"><script type="text/javascript">
//<![CDATA[
if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF11Sprite(2,'NIKE, Inc. 2026 Annual Report','');
} else {
	_EZF11Sprite(2,'{hosting_BtnCustom4stripped}','');
}
//]]>
</script>
<script type="text/javascript">
//<![CDATA[ 
	if (_ezPI03 == 0 || '{kit_iskitjob}' != 'Y') {
	_EZF51(1,'NIKE, Inc. 2026 Annual Report','','NIKE, Inc. 2026 Annual Report');
} else {
	_EZF51(1,'{hosting_BtnCustom4stripped}','','{hosting_BtnCustom4stripped}');
}
//]]>
</script>
</li>
<li class="hide0"><a class="hide1 nav-PrintBottomOn" id="nav-PrintIsCurrentPageOn-Bottom"><span>Print</span></a></li>
<li class="hide0"><a class="hide1 show1 nav-PrintBottomDisabled" id="nav-PrintIsCurrentPageDisabled-Bottom"><span>Print</span></a></li>
<li class="hide0"><a href="print.htm?p1url=nike-shareholder_letter_2026_0001.pdf&amp;p1thu=thumb_nike-shareholder_letter_2026_0001.gif&amp;p2url=&amp;p2thu=" class="show1 nav-PrintBottom" id="nav-PrintNormal-Bottom"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Print" title="Print" /><span>Print</span></a></li>
<li class="show1"><a class="hide1 nav-IndexBottomOn"><span>Clickable Index</span></a></li>
<li class="show1"><a href="contents.htm" class="show1 nav-IndexBottom"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Clickable Index" title="Clickable Index" /><span>Clickable Index</span></a></li>
<li class="show1"><a class="hide1 nav-ThumbsBottomOn"><span>Thumbnails</span></a></li>
<li class="show1"><a href="thumbnails.htm" class="show1 nav-ThumbsBottom"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Thumbnails" title="Thumbnails" /><span>Thumbnails</span></a></li>
<li class="hide0 show0 display1200orsmaller largescreenzoomplus" id="largescreenzoomplusbottom" style="display:none;"><a href="javascript:showBigZoomDesktop('0','false');" class="nav-ZoomPlusBottom"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 hide0 largescreenzoomplus" id="largescreenzoomplustwopagebottom" style="display:none;"><a href="javascript:showBigZoomDesktop('0','false');" class="nav-ZoomPlusBottom"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>
<li class="hide0 largescreenzoomplusdisabled display1200orsmaller" id="largescreenzoomplusdisabledbottom" style=""><a href="#" class="nav-ZoomPlusBottomDisabled"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Zoom In" title="Zoom In" /><span>Zoom In</span></a></li>

<li class="hide0"><a class="hide1 nav-HelpBottomOn"><span>Help</span></a></li>
<li class="hide0"><a href="help.htm" class="show1 nav-HelpBottom"><img src="../images/blank.gif" class="blankgifspacerbuttons" alt="Help" title="Help" /><span>Help</span></a></li>
</ul>

<script type="text/javascript">
//<![CDATA[
if (_ez60 == 0) {
	_EZF01();
	document.write('<div class="searchdiv"><form class=""ez_searchbox"" id="jse_Form2" name="jse_Form2" method="get" action="' + _ez01 + '" onsubmit="return _EZF02(\'d2\');">');
	_EZF13_Sprite(2);
	document.write('</form></div>');
}
//]]>
</script>
</span>
<span class="ezod_linearnavigation" id="LinearNavSpanBottom">
<div class="ez_pageprevnextbottom">
<ul>
<li class="hide0 show0 show1"><a href="javascript:_ezFH1008('HTML1','tiles.htm');" class="nav-PrevPageBottom"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="hide0 hide0"><a class="hide0 nav-PrevPageBottomDisabled"><span>Go to previous page</span></a></li>
<li class="hide0 hide1"><a class="hide0 nav-PrevPageBottomDisabled"><span>Go to previous page</span></a></li>
<li class="show0"><a href="{prevurl}" class="show0 nav-PrevPageBottom"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to previous page" title="Go to previous page" /><span>Go to previous page</span></a></li>
<li class="show1"><a href="financials.htm" class="show1 nav-NextPageBottom"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
<li class="hide1 show1"><a class="hide1 nav-NextPageBottomDisabled"><span>Go to next page</span></a></li>
<li class="hide1 hide1"><a href="default.htm" class="nav-NextPageBottom"><img src="../images/blank.gif" class="blankgifspacerprevnext" alt="Go to next page" title="Go to next page" /><span>Go to next page</span></a></li>
</ul>
</div>


<script type="text/javascript" src="../Text/jse_pdfpagenumbering.js"></script>
<script type="text/javascript">
//<![CDATA[
write_dropdownmenudiv('1');
//]]>
</script>

<!--PAGENOTZEROSTART-->
<noscript>
		<div class="ez_pagenumtext2">Page&nbsp;1&nbsp;of&nbsp;2</div>
</noscript>
<script type="text/javascript">
//<![CDATA[
_EZF24Div(2,'Page','of','1',2,'','1','#333333');
//]]>
</script>
<!--PAGENOTZEROEND-->
</span>

</div></div></div> 

<style>
#ez_menubox .EZ_hasThirdLevelMenu::after, #ez_mobilemenubox .EZ_hasThirdLevelMenu::after { content: '\00A0\00BB'; float:right; position: absolute; top: 2px; right: 2px; }
/* must be in HTML or chrome breaks */
</style>

<script type="text/javascript">
$(function() {
_EZF62(); // FrameKit
_EZF110(); // Tiles
setPageURLCookie(); //Page Cookie
setMobileReturnURL('#mobilelogolink');
setMobileReturnURL('#desklogolink');
$("[class^=EZODLevel3Container]").prev().addClass('EZ_hasThirdLevelMenu');
});
</script>


</div>
</div>

<div class="container ezfootercontainer">
<div class="ezfooterbox-left">
<div id="ez_navbartopbox" class="display960orlarger"><div id="ez_navbartop">		
<hr class="ez_navbar_hr" />			
<span class="hide0"><a href="https://www.nike.com" class="ez_navbartop" target="_blank">Company Home</a>|&nbsp;</span>					

<!--ONEPDFSTART--> 
<span class="show0"><a href="accessibility.htm" class="ez_navbartop">Accessibility Features</a>|&nbsp;</span>
<span class="hide0"><a href="../images/NIKE-Shareholder_Letter_2026.pdf" class="ez_navbartop" target="_blank">Download PDF</a>|&nbsp;</span>
<!--ONEPDFEND-->
<span class="hide0"><a href="print.htm?p1url=nike-shareholder_letter_2026_0001.pdf&amp;p1thu=thumb_nike-shareholder_letter_2026_0001.gif&amp;p2url=&amp;p2thu=" class="ez_navbartop">Print</a>|&nbsp;</span>
<span class="hide0"><a href="help.htm" class="ez_navbartop">Help</a></span>

  
<hr class="ez_navbar_hr" />
</div></div>


</div>
<div class="ezfooterbox-right">
<!-- REMOVED -->
</div>
</div>

<div id="JSOffFooter" class="JSOffFooter" style="display:block; width:750px;">
WARNING: JavaScript is disabled. <a href="../default.htm">CLICK HERE</a> for help.
<br />
</div>
<div id="BrowserCheckFooter" class="BrowserCheckFooter"  style="display:none; width:750px;">
<div style="padding-left:30px; padding-right:30px; text-align:left;">
<a href="http://www.ezonlinedocuments.com/browserupgrade.aspx?lang=english" target="_blank">Click here</a> for a list of supported browsers.
</div>
<br />
</div>

<script type="text/javascript">
//<![CDATA[
document.getElementById('JSOffFooter').style.display="none";
BrowserDetection.init(false);
if (oldBrowser) {
	document.getElementById('BrowserCheckFooter').style.display="block";
}
//]]>
</script>

<div class="ezpush"></div>
</div>
<div id="ez_mobilefooter" class="clearfix display768orsmaller ezfooter hide0" style="display: block; width:100%; height:28px;">
	<div class="container clearfix" style="width: 100%;">
		
		<div style="float:left; width:20%; height:28px;" onClick="prevPage();">
		<div style="width:12px; float:left; padding-top:5px; padding-left:5px;">
<ul style="list-style-type: none; margin: 0; padding: 0;">
<li class="hide0 show0 show1"><a href="javascript:_ezFH1008('HTML1','tiles.htm');" class="nav-PrevPageMobile"><img src="../images/blank.gif"  alt="Go to previous page" title="Go to previous page" /></a></li>
<li class="show0"><a href="{prevurl}" class="show0 nav-PrevPageMobile"><img src="../images/blank.gif"  alt="Go to previous page" title="Go to previous page" /></a></li>
</ul>
</div>
<div class="navMobileText show0" style="float:left; width:30px; padding-top:9px; padding-left:2px;"><a href="{prevurl}" style="text-decoration:none;">Prev</a></div>
<div class="navMobileText hide0" style="float:left; width:30px; padding-top:9px; padding-left:2px;"><a href="tiles.htm" class="show0 show1" style="text-decoration:none;">Prev</a></div>
<div class="clearfix"></div>
</div>
		
<div style="float:left; width:60%; height:28px;"><div id="mobilefooterpagetotal" style="">Page&nbsp;1&nbsp;of&nbsp;2</div></div>


<div style="float:right; width:20%; height:28px;" onClick="nextPage();">
		<div style="width:12px; float:right; padding-top:5px; padding-right:5px; padding-left:5px;">
<ul style="list-style-type: none; margin: 0; padding: 0;">
<li class="show1"><a href="financials.htm" class="show1 nav-NextPageMobile"><img src="../images/blank.gif" alt="Go to next page" title="Go to next page" /></a></li>
<li class="hide1 hide1"><a href="default.htm" class="nav-NextPageMobile"><img src="../images/blank.gif" alt="Go to next page" title="Go to next page" /></a></li>
</ul>
</div>
<div class="navMobileText show1" style="float:right; width:25px; padding-top:9px;"><a href="financials.htm" style="text-decoration:none;">Next</a></div>
<div class="navMobileText hide1 hide1" style="float:right; width:25px; padding-top:9px;"><a href="default.htm" style="text-decoration:none;">Next</a></div>
<div class="clearfix"></div>
</div>

<script>
function nextPage() {
if ('1' == '0') {
location.href = 'default.htm';
} else if ('1' == '1' ) {
location.href = 'financials.htm';
}

}

function prevPage() {
if ('0' == '0' && '0' == '1' && '1' == '1' ) {
_ezFH1008('HTML1','tiles.htm');
} else if ('0' == '1' ) {
location.href = '{prevurl}';
}

}

</script>

</div>
</div>



</body>
</html>

